<?php

declare(strict_types=1);

namespace App\Core;

use PDO;

/**
 * Runs SQL migration files found in database/migrations in filename order,
 * tracking applied migrations in a `migrations` table (mirrors Laravel's
 * migration ledger behaviour).
 */
final class Migrator
{
    public function __construct(private readonly PDO $pdo, private readonly string $migrationsPath)
    {
    }

    public function run(): array
    {
        $this->pdo->exec('CREATE TABLE IF NOT EXISTS migrations (id INTEGER PRIMARY KEY AUTOINCREMENT, migration TEXT NOT NULL UNIQUE, applied_at TEXT NOT NULL)');

        $applied = $this->pdo->query('SELECT migration FROM migrations')->fetchAll(PDO::FETCH_COLUMN);
        $files = glob($this->migrationsPath . '/*.php') ?: [];
        sort($files);

        $ran = [];
        foreach ($files as $file) {
            $name = basename($file, '.php');
            if (in_array($name, $applied, true)) {
                continue;
            }

            $migration = require $file;
            if (! is_array($migration) || ! isset($migration['up']) || ! is_callable($migration['up'])) {
                Logger::error('Invalid migration file skipped', ['file' => $file]);
                continue;
            }

            $migration['up']($this->pdo);

            $stmt = $this->pdo->prepare('INSERT INTO migrations (migration, applied_at) VALUES (:m, :a)');
            $stmt->execute(['m' => $name, 'a' => date('c')]);
            $ran[] = $name;
            Logger::info('Migration applied', ['migration' => $name]);
        }

        return $ran;
    }

    public function fresh(): array
    {
        $this->pdo->exec('DROP TABLE IF EXISTS migrations');
        $tables = $this->pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")->fetchAll(PDO::FETCH_COLUMN);
        $this->pdo->exec('PRAGMA foreign_keys = OFF');
        foreach ($tables as $table) {
            $this->pdo->exec('DROP TABLE IF EXISTS "' . $table . '"');
        }
        $this->pdo->exec('PRAGMA foreign_keys = ON');

        return $this->run();
    }
}
