<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Minimal structured logger writing JSON lines to storage/logs/revolit.log.
 *
 * Stands in for Laravel's Monolog-backed logging facade (unavailable offline).
 * Every module is required by project policy to log meaningful business
 * events and errors; this class is the single sink used across modules.
 */
final class Logger
{
    private static ?string $logPath = null;

    public static function configure(string $path): void
    {
        self::$logPath = $path;
    }

    private static function path(): string
    {
        if (self::$logPath !== null) {
            return self::$logPath;
        }

        $dir = dirname(__DIR__, 2) . '/storage/logs';
        if (! is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        return self::$logPath = $dir . '/revolit.log';
    }

    private static function write(string $level, string $message, array $context = []): void
    {
        $entry = [
            'timestamp' => date('c'),
            'level' => $level,
            'message' => $message,
            'context' => $context,
        ];

        file_put_contents(self::path(), json_encode($entry, JSON_UNESCAPED_UNICODE) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }

    public static function info(string $message, array $context = []): void
    {
        self::write('info', $message, $context);
    }

    public static function warning(string $message, array $context = []): void
    {
        self::write('warning', $message, $context);
    }

    public static function error(string $message, array $context = []): void
    {
        self::write('error', $message, $context);
    }
}
