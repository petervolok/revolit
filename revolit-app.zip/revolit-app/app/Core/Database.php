<?php

declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOException;
use RuntimeException;

/**
 * Thin PDO wrapper acting as the application's single connection manager.
 *
 * Laravel's Eloquent/DB facade is unavailable because no Composer packages
 * could be fetched from the network in this environment (see ARCHITECTURE.md,
 * "Known environment limitation"). This class intentionally mirrors the
 * subset of Laravel's DB responsibilities the modules need: a shared PDO
 * connection, migration bootstrapping and transactional helpers.
 */
final class Database
{
    private static ?PDO $connection = null;

    private static ?string $dsn = null;

    public static function configure(string $dsn): void
    {
        self::$dsn = $dsn;
        self::$connection = null;
    }

    public static function connection(): PDO
    {
        if (self::$connection instanceof PDO) {
            return self::$connection;
        }

        $dsn = self::$dsn ?? (getenv('REVOLIT_DB_DSN') ?: 'sqlite:' . dirname(__DIR__, 2) . '/storage/database.sqlite');

        try {
            $pdo = new PDO($dsn);
        } catch (PDOException $exception) {
            Logger::error('Database connection failed', ['dsn' => $dsn, 'error' => $exception->getMessage()]);

            throw new RuntimeException('Unable to connect to database: ' . $exception->getMessage(), previous: $exception);
        }

        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

        if (str_starts_with($dsn, 'sqlite:')) {
            $pdo->exec('PRAGMA foreign_keys = ON;');
        }

        self::$connection = $pdo;

        return $pdo;
    }

    public static function reset(): void
    {
        self::$connection = null;
    }

    public static function transaction(callable $callback): mixed
    {
        $pdo = self::connection();
        $pdo->beginTransaction();

        try {
            $result = $callback($pdo);
            $pdo->commit();

            return $result;
        } catch (\Throwable $exception) {
            $pdo->rollBack();
            Logger::error('Transaction rolled back', ['error' => $exception->getMessage()]);

            throw $exception;
        }
    }
}
