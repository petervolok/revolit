<?php

declare(strict_types=1);

namespace App\Core;

use App\Modules\Banquet\Services\BanquetProcessService;
use App\Modules\Banquet\Services\PdfGenerator;
use App\Modules\Certification\Services\CertificationProcessService;
use App\Modules\EntityBuilder\Services\EntityRecordRelationService;
use App\Modules\EntityBuilder\Services\EntityRecordService;
use App\Modules\EntityBuilder\Services\EntityService;
use App\Modules\EntityBuilder\Services\RoleService;
use App\Modules\EntityBuilder\Services\UserRepository;
use App\Modules\Marketplace\Services\ModuleInstallerService;
use App\Modules\Marketplace\Services\ModuleRegistryService;
use App\Modules\WorkflowEngine\Executors\AiAgentExecutor;
use App\Modules\WorkflowEngine\Executors\HumanExecutor;
use App\Modules\WorkflowEngine\Services\WorkflowRunner;
use App\Modules\WorkflowEngine\Services\WorkflowService;
use PDO;

/**
 * Tiny service container replacing Laravel's IoC container for this
 * offline build: wires the concrete implementations (including the
 * HumanExecutor/AiAgentExecutor binding for AgentExecutorInterface).
 */
final class Application
{
    private PDO $pdo;

    public function __construct(?string $dsn = null)
    {
        if ($dsn !== null) {
            Database::configure($dsn);
        }

        $this->pdo = Database::connection();
    }

    public function pdo(): PDO
    {
        return $this->pdo;
    }

    public function migrate(bool $fresh = false): array
    {
        $migrator = new Migrator($this->pdo, dirname(__DIR__, 2) . '/database/migrations');

        return $fresh ? $migrator->fresh() : $migrator->run();
    }

    public function entityService(): EntityService
    {
        return new EntityService($this->pdo);
    }

    public function entityRecordService(): EntityRecordService
    {
        return new EntityRecordService($this->pdo, $this->entityService());
    }

    public function userRepository(): UserRepository
    {
        return new UserRepository($this->pdo);
    }

    public function workflowService(): WorkflowService
    {
        return new WorkflowService($this->pdo);
    }

    public function workflowRunner(): WorkflowRunner
    {
        return new WorkflowRunner($this->pdo, new HumanExecutor($this->pdo), new AiAgentExecutor());
    }

    public function roleService(): RoleService
    {
        return new RoleService($this->pdo);
    }

    public function relationService(): EntityRecordRelationService
    {
        return new EntityRecordRelationService($this->pdo);
    }

    public function moduleRegistryService(): ModuleRegistryService
    {
        return new ModuleRegistryService($this->pdo);
    }

    public function moduleInstallerService(): ModuleInstallerService
    {
        return new ModuleInstallerService(
            $this->pdo,
            $this->moduleRegistryService(),
            $this->entityService(),
            $this->workflowService(),
            $this->roleService(),
        );
    }

    public function banquetProcess(int $banquetEntityId, int $menuItemEntityId, int $workflowId): BanquetProcessService
    {
        return new BanquetProcessService(
            $this->pdo,
            $this->entityRecordService(),
            $this->workflowRunner(),
            new PdfGenerator(),
            $banquetEntityId,
            $menuItemEntityId,
            $workflowId,
        );
    }

    public function certificationProcess(
        int $clientEntityId,
        int $documentEntityId,
        int $invoiceEntityId,
        int $cashOperationEntityId,
        int $reminderEntityId,
        int $expiryWorkflowId,
    ): CertificationProcessService {
        return new CertificationProcessService(
            $this->pdo,
            $this->entityRecordService(),
            $this->relationService(),
            $this->entityService(),
            $this->workflowRunner(),
            $clientEntityId,
            $documentEntityId,
            $invoiceEntityId,
            $cashOperationEntityId,
            $reminderEntityId,
            $expiryWorkflowId,
        );
    }
}
