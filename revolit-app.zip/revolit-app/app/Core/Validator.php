<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Small rule-based validator mirroring Laravel's Validator/FormRequest
 * contract: rules are declared as "field" => "rule1|rule2:param" strings and
 * validated against real input data. No mocked or bypassed validation paths.
 */
final class Validator
{
    /** @var array<string, array<int, string>> */
    private array $errors = [];

    /**
     * @param array<string, mixed> $data
     * @param array<string, string> $rules
     * @param array<string, string> $attributeLabels
     */
    private function __construct(
        private readonly array $data,
        private readonly array $rules,
        private readonly array $attributeLabels = []
    ) {
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, string> $rules
     * @param array<string, string> $attributeLabels
     */
    public static function make(array $data, array $rules, array $attributeLabels = []): self
    {
        return new self($data, $rules, $attributeLabels);
    }

    /**
     * @return array<string, mixed> validated data (only keys present in rules)
     *
     * @throws ValidationException
     */
    public function validate(): array
    {
        $validated = [];

        foreach ($this->rules as $field => $ruleString) {
            $rules = explode('|', $ruleString);
            $value = $this->data[$field] ?? null;
            $nullable = in_array('nullable', $rules, true);

            if ($value === null || $value === '') {
                if ($nullable) {
                    $validated[$field] = null;
                    continue;
                }
            }

            foreach ($rules as $rule) {
                if ($rule === 'nullable') {
                    continue;
                }

                if (($value === null || $value === '') && $rule !== 'required') {
                    continue;
                }

                $this->applyRule($field, $rule, $value);
            }

            if (! array_key_exists($field, $this->errors)) {
                $validated[$field] = $value;
            }
        }

        if ($this->errors !== []) {
            throw new ValidationException($this->errors);
        }

        return $validated;
    }

    private function applyRule(string $field, string $rule, mixed $value): void
    {
        [$name, $parameter] = array_pad(explode(':', $rule, 2), 2, null);
        $label = $this->attributeLabels[$field] ?? $field;

        $valid = match ($name) {
            'required' => $value !== null && $value !== '',
            'string' => is_string($value),
            'integer' => is_int($value) || (is_string($value) && ctype_digit($value)),
            'numeric' => is_numeric($value),
            'boolean' => is_bool($value) || in_array($value, [0, 1, '0', '1', true, false], true),
            'array' => is_array($value),
            'date' => $this->isValidDate($value),
            'email' => is_string($value) && filter_var($value, FILTER_VALIDATE_EMAIL) !== false,
            'in' => in_array((string) $value, explode(',', (string) $parameter), true),
            'max' => $this->passesMax($value, (int) $parameter),
            'min' => $this->passesMin($value, (int) $parameter),
            default => true,
        };

        if (! $valid) {
            $this->errors[$field][] = $this->message($name, $label, $parameter);
        }
    }

    private function isValidDate(mixed $value): bool
    {
        if (! is_string($value)) {
            return false;
        }

        $date = \DateTime::createFromFormat('Y-m-d', $value) ?: \DateTime::createFromFormat('Y-m-d H:i:s', $value);

        return $date !== false;
    }

    private function passesMax(mixed $value, int $max): bool
    {
        if (is_string($value)) {
            return mb_strlen($value) <= $max;
        }

        if (is_numeric($value)) {
            return (float) $value <= $max;
        }

        return true;
    }

    private function passesMin(mixed $value, int $min): bool
    {
        if (is_string($value)) {
            return mb_strlen($value) >= $min;
        }

        if (is_numeric($value)) {
            return (float) $value >= $min;
        }

        return true;
    }

    private function message(?string $rule, string $label, ?string $parameter): string
    {
        return match ($rule) {
            'required' => "The {$label} field is required.",
            'string' => "The {$label} must be a string.",
            'integer' => "The {$label} must be an integer.",
            'numeric' => "The {$label} must be numeric.",
            'boolean' => "The {$label} must be true or false.",
            'array' => "The {$label} must be an array.",
            'date' => "The {$label} is not a valid date.",
            'email' => "The {$label} must be a valid email address.",
            'in' => "The selected {$label} is invalid.",
            'max' => "The {$label} may not be greater than {$parameter}.",
            'min' => "The {$label} must be at least {$parameter}.",
            default => "The {$label} is invalid.",
        };
    }
}
