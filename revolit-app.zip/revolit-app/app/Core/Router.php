<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Minimal HTTP router (method + path pattern with {param} placeholders)
 * substituting Laravel's routes/api.php + Route facade for the offline
 * skeleton. Registered from routes/api.php.
 */
final class Router
{
    /** @var array<int, array{method: string, pattern: string, handler: callable}> */
    private array $routes = [];

    public function add(string $method, string $pattern, callable $handler): void
    {
        $this->routes[] = ['method' => strtoupper($method), 'pattern' => $pattern, 'handler' => $handler];
    }

    public function get(string $pattern, callable $handler): void
    {
        $this->add('GET', $pattern, $handler);
    }

    public function post(string $pattern, callable $handler): void
    {
        $this->add('POST', $pattern, $handler);
    }

    public function put(string $pattern, callable $handler): void
    {
        $this->add('PUT', $pattern, $handler);
    }

    public function dispatch(string $method, string $uri): void
    {
        $path = parse_url($uri, PHP_URL_PATH) ?: '/';

        foreach ($this->routes as $route) {
            if ($route['method'] !== strtoupper($method)) {
                continue;
            }

            $params = $this->match($route['pattern'], $path);
            if ($params === null) {
                continue;
            }

            try {
                $result = ($route['handler'])($params);
                $this->respond($result);
            } catch (ValidationException $exception) {
                Logger::warning('Request validation failed', ['path' => $path, 'errors' => $exception->errors()]);
                $this->respond(['error' => 'validation_failed', 'errors' => $exception->errors()], 422);
            } catch (\Throwable $exception) {
                Logger::error('Unhandled request exception', ['path' => $path, 'error' => $exception->getMessage()]);
                $this->respond(['error' => $exception->getMessage()], 500);
            }

            return;
        }

        $this->respond(['error' => 'not_found'], 404);
    }

    /**
     * @return array<string, string>|null
     */
    private function match(string $pattern, string $path): ?array
    {
        $patternParts = explode('/', trim($pattern, '/'));
        $pathParts = explode('/', trim($path, '/'));

        if (count($patternParts) !== count($pathParts)) {
            return null;
        }

        $params = [];
        foreach ($patternParts as $i => $part) {
            if (str_starts_with($part, '{') && str_ends_with($part, '}')) {
                $params[substr($part, 1, -1)] = $pathParts[$i];
            } elseif ($part !== $pathParts[$i]) {
                return null;
            }
        }

        return $params;
    }

    private function respond(mixed $result, int $status = 200): void
    {
        if (is_array($result) && isset($result['__raw__'])) {
            http_response_code($result['status'] ?? 200);
            foreach ($result['headers'] ?? [] as $name => $value) {
                header("{$name}: {$value}");
            }
            echo $result['body'];

            return;
        }

        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
}
