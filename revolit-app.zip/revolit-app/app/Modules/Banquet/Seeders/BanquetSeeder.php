<?php

declare(strict_types=1);

namespace App\Modules\Banquet\Seeders;

use App\Core\Logger;
use App\Modules\Banquet\BanquetModuleManifest;
use App\Modules\EntityBuilder\Services\EntityService;
use App\Modules\EntityBuilder\Services\RoleService;
use App\Modules\Marketplace\Services\ModuleInstallerService;
use App\Modules\Marketplace\Services\ModuleRegistryService;
use App\Modules\WorkflowEngine\Services\WorkflowService;
use PDO;

/**
 * Pilot application case ("Банкетный ресторан"). It no longer builds
 * entities/workflow by hand: BanquetModuleManifest describes the whole
 * case as a marketplace module manifest, and this seeder simply registers
 * it and installs it into a fresh workspace through ModuleInstallerService
 * - the same path any marketplace module install goes through. This is
 * the reference pattern any future vertical (e.g. Certification) follows.
 */
final class BanquetSeeder
{
    public function __construct(
        private readonly PDO $pdo,
        private readonly EntityService $entities,
        private readonly WorkflowService $workflows,
    ) {
    }

    /**
     * @return array{workspace_id: int, roles: array<string, int>, entities: array<string, int>, workflow_id: int}
     */
    public function seed(): array
    {
        $workspaceId = $this->createWorkspace();

        $registry = new ModuleRegistryService($this->pdo);
        $installer = new ModuleInstallerService($this->pdo, $registry, $this->entities, $this->workflows, new RoleService($this->pdo));

        $moduleId = $registry->register(BanquetModuleManifest::manifest());
        $installation = $installer->install($moduleId, $workspaceId);

        Logger::info('Banquet pilot case seeded via marketplace module', [
            'workspace_id' => $workspaceId,
            'installation_id' => $installation['installation_id'],
        ]);

        return [
            'workspace_id' => $workspaceId,
            'roles' => $installation['roles'],
            'entities' => $installation['entities'],
            'workflow_id' => $installation['workflows']['Банкет: согласование'],
        ];
    }

    private function createWorkspace(): int
    {
        $now = date('c');
        $stmt = $this->pdo->prepare('INSERT INTO workspaces (name, slug, created_at, updated_at) VALUES (:n, :s, :c, :u)');
        $stmt->execute(['n' => 'Банкетный ресторан «Ривьера»', 's' => 'riviera-' . bin2hex(random_bytes(4)), 'c' => $now, 'u' => $now]);

        return (int) $this->pdo->lastInsertId();
    }
}
