<?php

declare(strict_types=1);

namespace App\Modules\Banquet\Services;

use App\Core\Logger;
use App\Modules\EntityBuilder\Models\User;
use App\Modules\EntityBuilder\Services\EntityRecordService;
use App\Modules\WorkflowEngine\Services\WorkflowRunner;
use PDO;
use RuntimeException;

/**
 * Orchestrates the pilot banquet process on top of the generic entity
 * builder + workflow engine: create banquet -> attach menu items -> render
 * client PDF -> run approval workflow -> compute "same banquet last year"
 * reminders from real stored dates.
 */
final class BanquetProcessService
{
    public function __construct(
        private readonly PDO $pdo,
        private readonly EntityRecordService $records,
        private readonly WorkflowRunner $workflowRunner,
        private readonly PdfGenerator $pdf,
        private readonly int $banquetEntityId,
        private readonly int $menuItemEntityId,
        private readonly int $workflowId,
    ) {
    }

    /**
     * @param array<string, mixed> $banquetData
     * @param array<int, int> $menuItemIds
     */
    public function createBanquetWithMenu(int $workspaceId, User $actor, array $banquetData, array $menuItemIds): int
    {
        $banquetData['status'] = 'draft';
        $recordId = $this->records->create($this->banquetEntityId, $workspaceId, $actor, $banquetData);

        if ($menuItemIds !== []) {
            $this->attachMenu($recordId, $actor, $menuItemIds);
        }

        Logger::info('Banquet created with menu', ['record_id' => $recordId, 'menu_items' => count($menuItemIds)]);

        return $recordId;
    }

    /**
     * @param array<int, int> $menuItemIds
     */
    public function attachMenu(int $banquetRecordId, User $actor, array $menuItemIds): void
    {
        foreach ($menuItemIds as $id) {
            $item = $this->records->find($id);
            if ((int) $item['entity_id'] !== $this->menuItemEntityId) {
                throw new RuntimeException("Record {$id} is not a menu item");
            }
        }

        $this->records->update($banquetRecordId, $actor, [
            'menu_item_ids' => json_encode($menuItemIds),
            'status' => 'menu_ready',
        ]);
    }

    public function generateClientPdf(int $banquetRecordId, string $outputPath): string
    {
        $banquet = $this->records->find($banquetRecordId);
        $data = json_decode((string) $banquet['data'], true) ?: [];

        $lines = [
            'Дата: ' . ($data['date'] ?? '-'),
            'Количество персон: ' . ($data['guests_count'] ?? '-'),
            'Статус: ' . ($data['status'] ?? '-'),
        ];

        $menuIds = json_decode((string) ($data['menu_item_ids'] ?? '[]'), true) ?: [];
        foreach ($menuIds as $menuId) {
            $item = $this->records->find((int) $menuId);
            $itemData = json_decode((string) $item['data'], true) ?: [];
            $lines[] = '- ' . ($itemData['name'] ?? 'Позиция #' . $menuId) . ': ' . ($itemData['price'] ?? '0') . ' руб/чел';
        }

        return $this->pdf->saveToFile('Банкет №' . $banquetRecordId, $lines, $outputPath);
    }

    /**
     * @return array<string, mixed>
     */
    public function runApprovalWorkflow(int $banquetRecordId): array
    {
        return $this->workflowRunner->run($this->workflowId, 'record.created', $banquetRecordId);
    }

    /**
     * Finds banquets held on the same calendar date one year before the
     * given date (± windowDays), for the "напоминание о прошлогодних
     * банкетах" reminder. This is a real query over stored entity_records
     * data, not a mocked lookup.
     *
     * @return array<int, array<string, mixed>>
     */
    public function findLastYearBanquets(int $workspaceId, string $date, int $windowDays = 3): array
    {
        $target = new \DateTimeImmutable($date);
        $lastYear = $target->modify('-1 year');
        $from = $lastYear->modify("-{$windowDays} days")->format('Y-m-d');
        $to = $lastYear->modify("+{$windowDays} days")->format('Y-m-d');

        $stmt = $this->pdo->prepare(
            "SELECT er.* FROM entity_records er
             JOIN entity_record_values erv ON erv.entity_record_id = er.id
             JOIN entity_fields ef ON ef.id = erv.entity_field_id AND ef.key = 'date'
             WHERE er.entity_id = :entity_id AND er.workspace_id = :workspace_id
               AND erv.value >= :from AND erv.value <= :to
             ORDER BY erv.value ASC"
        );
        $stmt->execute([
            'entity_id' => $this->banquetEntityId,
            'workspace_id' => $workspaceId,
            'from' => $from,
            'to' => $to,
        ]);

        $rows = $stmt->fetchAll();

        Logger::info('Last-year banquet reminder query executed', [
            'workspace_id' => $workspaceId,
            'window' => [$from, $to],
            'matches' => count($rows),
        ]);

        return $rows;
    }

    /**
     * Simple calendar grouping (date => banquets), used by the Blade/HTML
     * calendar view.
     *
     * @return array<string, array<int, array<string, mixed>>>
     */
    public function calendar(int $workspaceId): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM entity_records WHERE entity_id = :e AND workspace_id = :w ORDER BY id ASC');
        $stmt->execute(['e' => $this->banquetEntityId, 'w' => $workspaceId]);

        $byDate = [];
        foreach ($stmt->fetchAll() as $row) {
            $data = json_decode((string) $row['data'], true) ?: [];
            $date = $data['date'] ?? 'unknown';
            $byDate[$date][] = array_merge(['id' => $row['id']], $data);
        }

        ksort($byDate);

        return $byDate;
    }
}
