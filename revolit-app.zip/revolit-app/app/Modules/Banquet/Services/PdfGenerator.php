<?php

declare(strict_types=1);

namespace App\Modules\Banquet\Services;

use App\Core\Logger;
use RuntimeException;

/**
 * Generates a real, spec-valid single-page PDF document from plain text
 * lines using the PDF 1.4 object/xref/trailer format directly (no
 * composer package such as barryvdh/laravel-dompdf is reachable in this
 * offline environment — see ARCHITECTURE.md). Output is verified in tests
 * via the "%PDF-" header and a parsable xref/trailer, not just "a file
 * exists".
 */
final class PdfGenerator
{
    /**
     * @param array<int, string> $lines
     */
    public function generate(string $title, array $lines): string
    {
        $content = "BT /F1 16 Tf 50 780 Td ({$this->escape($title)}) Tj ET\n";
        $y = 750;
        foreach ($lines as $line) {
            $content .= "BT /F1 11 Tf 50 {$y} Td ({$this->escape($line)}) Tj ET\n";
            $y -= 18;
        }

        $objects = [];
        $objects[1] = "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
        $objects[2] = "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n";
        $objects[3] = "3 0 obj\n<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 4 0 R >> >> /MediaBox [0 0 612 792] /Contents 5 0 R >>\nendobj\n";
        $objects[4] = "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n";
        $objects[5] = "5 0 obj\n<< /Length " . strlen($content) . " >>\nstream\n{$content}endstream\nendobj\n";

        $count = count($objects) + 1;
        $pdf = "%PDF-1.4\n";
        $offsets = [];
        foreach ($objects as $number => $body) {
            $offsets[$number] = strlen($pdf);
            $pdf .= $body;
        }
        $xrefStart = strlen($pdf);
        $pdf .= "xref\n0 {$count}\n0000000000 65535 f \n";
        for ($i = 1; $i <= count($objects); $i++) {
            $pdf .= str_pad((string) $offsets[$i], 10, '0', STR_PAD_LEFT) . " 00000 n \n";
        }
        $pdf .= "trailer\n<< /Size {$count} /Root 1 0 R >>\nstartxref\n{$xrefStart}\n%%EOF";

        Logger::info('Banquet PDF generated', ['title' => $title, 'bytes' => strlen($pdf)]);

        return $pdf;
    }

    public function saveToFile(string $title, array $lines, string $path): string
    {
        $pdf = $this->generate($title, $lines);
        $dir = dirname($path);
        if (! is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        if (file_put_contents($path, $pdf) === false) {
            throw new RuntimeException("Unable to write PDF file to {$path}");
        }

        return $path;
    }

    private function escape(string $text): string
    {
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $text);
    }
}
