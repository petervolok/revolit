<?php

declare(strict_types=1);

namespace App\Modules\Banquet;

/**
 * The pilot "Банкетный ресторан" case expressed as a marketplace module
 * manifest: everything BanquetSeeder used to build by hand (entities,
 * fields, the approval workflow) is now data, installed through
 * ModuleInstallerService like any other module would be. This is the
 * reference contract every future vertical module (Certification, ...)
 * follows.
 */
final class BanquetModuleManifest
{
    /**
     * @return array<string, mixed>
     */
    public static function manifest(): array
    {
        return [
            'slug' => 'banquet-restaurant',
            'name' => 'Банкетный ресторан',
            'version' => '1.0.0',
            'author' => 'Revolit',
            'description' => 'Приём заказов на банкеты: клиенты, залы, меню, согласование заказа.',
            'status' => 'published',
            'roles' => ['director' => 100, 'manager' => 50],
            'entities' => [
                [
                    'slug' => 'client',
                    'name' => 'Клиент',
                    'description' => 'Клиент банкетного ресторана',
                    'fields' => [
                        ['key' => 'name', 'label' => 'Имя', 'type' => 'string', 'is_required' => true],
                        ['key' => 'phone', 'label' => 'Телефон', 'type' => 'string', 'is_required' => true],
                    ],
                ],
                [
                    'slug' => 'hall',
                    'name' => 'Зал',
                    'description' => 'Банкетный зал',
                    'fields' => [
                        ['key' => 'name', 'label' => 'Название', 'type' => 'string', 'is_required' => true],
                        ['key' => 'tables_count', 'label' => 'Количество столов', 'type' => 'integer', 'is_required' => true],
                        ['key' => 'capacity', 'label' => 'Вместимость', 'type' => 'integer', 'is_required' => true],
                    ],
                ],
                [
                    'slug' => 'menu_item',
                    'name' => 'Меню-позиция',
                    'description' => 'Позиция банкетного меню',
                    'fields' => [
                        ['key' => 'name', 'label' => 'Название блюда', 'type' => 'string', 'is_required' => true],
                        ['key' => 'price', 'label' => 'Цена за персону', 'type' => 'decimal', 'is_required' => true],
                        ['key' => 'category', 'label' => 'Категория', 'type' => 'select', 'is_required' => true, 'options' => ['starter', 'main', 'dessert', 'drink']],
                    ],
                ],
                [
                    'slug' => 'banquet',
                    'name' => 'Банкет',
                    'description' => 'Заказ банкета',
                    'fields' => [
                        ['key' => 'client_id', 'label' => 'Клиент', 'type' => 'relation', 'is_required' => true],
                        ['key' => 'hall_id', 'label' => 'Зал', 'type' => 'relation', 'is_required' => true],
                        ['key' => 'date', 'label' => 'Дата', 'type' => 'date', 'is_required' => true],
                        ['key' => 'guests_count', 'label' => 'Количество персон', 'type' => 'integer', 'is_required' => true],
                        ['key' => 'status', 'label' => 'Статус', 'type' => 'select', 'is_required' => true, 'options' => ['draft', 'menu_ready', 'pending_approval', 'confirmed', 'cancelled']],
                        ['key' => 'deposit_amount', 'label' => 'Внесённая сумма', 'type' => 'decimal', 'is_required' => false],
                        ['key' => 'menu_item_ids', 'label' => 'Позиции меню', 'type' => 'text', 'is_required' => false],
                    ],
                ],
            ],
            'workflows' => [
                [
                    'name' => 'Банкет: согласование',
                    'entity_slug' => 'banquet',
                    'trigger_event' => 'record.created',
                    'graph' => [
                        'nodes' => [
                            ['id' => 'trigger', 'type' => 'trigger', 'event' => 'record.created'],
                            ['id' => 'has_menu', 'type' => 'condition', 'field' => 'status', 'operator' => 'equals', 'value' => 'menu_ready'],
                            ['id' => 'set_pending', 'type' => 'action', 'action' => 'set_field', 'field' => 'status', 'value' => 'pending_approval'],
                            ['id' => 'assign_manager', 'type' => 'action', 'action' => 'assign', 'assignee_type' => 'human'],
                        ],
                        'edges' => [
                            ['from' => 'trigger', 'to' => 'has_menu'],
                            ['from' => 'has_menu', 'to' => 'set_pending', 'branch' => 'true'],
                            ['from' => 'set_pending', 'to' => 'assign_manager'],
                        ],
                    ],
                ],
            ],
        ];
    }
}
