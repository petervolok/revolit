<?php

declare(strict_types=1);

namespace App\Modules\Certification\Seeders;

use App\Core\Logger;
use App\Modules\Certification\CertificationModuleManifest;
use App\Modules\EntityBuilder\Services\EntityService;
use App\Modules\EntityBuilder\Services\RoleService;
use App\Modules\Marketplace\Services\ModuleInstallerService;
use App\Modules\Marketplace\Services\ModuleRegistryService;
use App\Modules\WorkflowEngine\Services\WorkflowService;
use PDO;

/**
 * Installs the "Центр сертификации" marketplace module into a fresh
 * workspace, mirroring App\Modules\Banquet\Seeders\BanquetSeeder.
 */
final class CertificationSeeder
{
    public function __construct(
        private readonly PDO $pdo,
        private readonly EntityService $entities,
        private readonly WorkflowService $workflows,
    ) {
    }

    /**
     * @return array{workspace_id: int, roles: array<string, int>, entities: array<string, int>, workflow_id: int}
     */
    public function seed(): array
    {
        $workspaceId = $this->createWorkspace();

        $registry = new ModuleRegistryService($this->pdo);
        $installer = new ModuleInstallerService($this->pdo, $registry, $this->entities, $this->workflows, new RoleService($this->pdo));

        $moduleId = $registry->register(CertificationModuleManifest::manifest());
        $installation = $installer->install($moduleId, $workspaceId);

        Logger::info('Certification case seeded via marketplace module', [
            'workspace_id' => $workspaceId,
            'installation_id' => $installation['installation_id'],
        ]);

        return [
            'workspace_id' => $workspaceId,
            'roles' => $installation['roles'],
            'entities' => $installation['entities'],
            'workflow_id' => $installation['workflows']['Напоминание об истечении срока документа'],
        ];
    }

    private function createWorkspace(): int
    {
        $now = date('c');
        $stmt = $this->pdo->prepare('INSERT INTO workspaces (name, slug, created_at, updated_at) VALUES (:n, :s, :c, :u)');
        $stmt->execute(['n' => 'Центр сертификации «Эталон»', 's' => 'etalon-' . bin2hex(random_bytes(4)), 'c' => $now, 'u' => $now]);

        return (int) $this->pdo->lastInsertId();
    }
}
