<?php

declare(strict_types=1);

namespace App\Modules\Certification\Services;

use App\Core\Logger;
use App\Modules\EntityBuilder\Models\User;
use App\Modules\EntityBuilder\Policies\EntityRecordPolicy;
use App\Modules\EntityBuilder\Services\EntityRecordRelationService;
use App\Modules\EntityBuilder\Services\EntityRecordService;
use App\Modules\EntityBuilder\Services\EntityService;
use App\Modules\WorkflowEngine\Services\WorkflowRunner;
use DateTimeImmutable;
use PDO;
use RuntimeException;

/**
 * Orchestrates the "Центр сертификации" process on top of the generic
 * entity builder + workflow engine + relations, the same way
 * BanquetProcessService does for the banquet case: create client/document/
 * invoice -> relate invoice to document -> mark paid (director-only) ->
 * simple status/payment reports -> expiry-reminder scan that drives the
 * workflow engine's create_record action for real, stored reminders.
 */
final class CertificationProcessService
{
    public function __construct(
        private readonly PDO $pdo,
        private readonly EntityRecordService $records,
        private readonly EntityRecordRelationService $relations,
        private readonly EntityService $entityMeta,
        private readonly WorkflowRunner $workflowRunner,
        private readonly int $clientEntityId,
        private readonly int $documentEntityId,
        private readonly int $invoiceEntityId,
        private readonly int $cashOperationEntityId,
        private readonly int $reminderEntityId,
        private readonly int $expiryWorkflowId,
    ) {
    }

    /**
     * @param array<string, mixed> $data
     */
    public function createClient(int $workspaceId, User $actor, array $data, bool $isOwnerOnly = false): int
    {
        // Director-only clients reuse the Entity Builder's owner-only
        // mechanism: a director may create clients regular managers never
        // see, without any Certification-specific access-control code.
        if ($isOwnerOnly && $actor->roleLevel < EntityRecordPolicy::DIRECTOR_LEVEL) {
            Logger::warning('Non-director attempted to create an owner-only client', ['user_id' => $actor->id]);
            throw new RuntimeException('Only a director can create a private (owner-only) client.');
        }

        return $this->records->create($this->clientEntityId, $workspaceId, $actor, $data, $isOwnerOnly);
    }

    /**
     * @param array<string, mixed> $data
     */
    public function issueDocument(int $workspaceId, User $actor, array $data): int
    {
        $data['status'] = $data['status'] ?? 'active';

        return $this->records->create($this->documentEntityId, $workspaceId, $actor, $data);
    }

    /**
     * Issues an invoice and links it to the document it was raised for via
     * a real entity_record_relations row (`invoice_for_document`).
     *
     * @param array<string, mixed> $data
     */
    public function issueInvoice(int $workspaceId, User $actor, array $data, int $documentRecordId): int
    {
        $data['status'] = $data['status'] ?? 'unpaid';

        $invoiceId = $this->records->create($this->invoiceEntityId, $workspaceId, $actor, $data);
        $this->relations->relate($invoiceId, $documentRecordId, 'invoice_for_document');

        return $invoiceId;
    }

    /**
     * @param array<string, mixed> $data
     */
    public function recordCashOperation(int $workspaceId, User $actor, array $data): int
    {
        return $this->records->create($this->cashOperationEntityId, $workspaceId, $actor, $data);
    }

    /**
     * Only the director may mark an invoice as paid.
     */
    public function markInvoicePaid(User $actor, int $invoiceRecordId): void
    {
        if ($actor->roleLevel < EntityRecordPolicy::DIRECTOR_LEVEL) {
            Logger::warning('Non-director attempted to mark an invoice as paid', ['user_id' => $actor->id, 'invoice_id' => $invoiceRecordId]);
            throw new RuntimeException('Only a director can mark an invoice as paid.');
        }

        $this->records->update($invoiceRecordId, $actor, [
            'status' => 'paid',
            'paid_at' => date('Y-m-d'),
        ]);

        Logger::info('Invoice marked as paid', ['invoice_id' => $invoiceRecordId, 'by_user_id' => $actor->id]);
    }

    /**
     * Report: number of documents per status (active/expired/revoked).
     *
     * @return array<string, int>
     */
    public function documentsByStatusReport(int $workspaceId): array
    {
        $stmt = $this->pdo->prepare('SELECT data FROM entity_records WHERE entity_id = :e AND workspace_id = :w');
        $stmt->execute(['e' => $this->documentEntityId, 'w' => $workspaceId]);

        $counts = [];
        foreach ($stmt->fetchAll() as $row) {
            $data = json_decode((string) $row['data'], true) ?: [];
            $status = $data['status'] ?? 'unknown';
            $counts[$status] = ($counts[$status] ?? 0) + 1;
        }

        return $counts;
    }

    /**
     * Report: paid/unpaid invoice totals and counts.
     *
     * @return array{paid_amount: float, paid_count: int, unpaid_amount: float, unpaid_count: int}
     */
    public function invoiceTotalsReport(int $workspaceId): array
    {
        $stmt = $this->pdo->prepare('SELECT data FROM entity_records WHERE entity_id = :e AND workspace_id = :w');
        $stmt->execute(['e' => $this->invoiceEntityId, 'w' => $workspaceId]);

        $report = ['paid_amount' => 0.0, 'paid_count' => 0, 'unpaid_amount' => 0.0, 'unpaid_count' => 0];

        foreach ($stmt->fetchAll() as $row) {
            $data = json_decode((string) $row['data'], true) ?: [];
            $amount = (float) ($data['amount'] ?? 0);

            if (($data['status'] ?? null) === 'paid') {
                $report['paid_amount'] += $amount;
                $report['paid_count']++;
            } else {
                $report['unpaid_amount'] += $amount;
                $report['unpaid_count']++;
            }
        }

        return $report;
    }

    /**
     * Scans documents for those expiring within `daysAhead` days of `asOf`
     * and, for each one not already reminded about, runs the expiry
     * workflow (which creates a real `reminder` record via the workflow
     * engine's create_record action and links it back to the document).
     *
     * @return array<int, int> ids of newly created reminder records
     */
    public function checkExpiringDocuments(int $workspaceId, DateTimeImmutable $asOf, int $daysAhead = 30): array
    {
        $fieldIds = $this->documentFieldIds();

        $from = $asOf->format('Y-m-d');
        $to = $asOf->modify("+{$daysAhead} days")->format('Y-m-d');

        $stmt = $this->pdo->prepare(
            "SELECT er.id FROM entity_records er
             JOIN entity_record_values status_v ON status_v.entity_record_id = er.id
                AND status_v.entity_field_id = :status_field AND status_v.value = 'active'
             JOIN entity_record_values expiry_v ON expiry_v.entity_record_id = er.id
                AND expiry_v.entity_field_id = :expiry_field
             WHERE er.entity_id = :entity_id AND er.workspace_id = :workspace_id
               AND expiry_v.value >= :from AND expiry_v.value <= :to
             ORDER BY expiry_v.value ASC"
        );
        $stmt->execute([
            'status_field' => $fieldIds['status'],
            'expiry_field' => $fieldIds['expiry_date'],
            'entity_id' => $this->documentEntityId,
            'workspace_id' => $workspaceId,
            'from' => $from,
            'to' => $to,
        ]);

        $documentIds = array_map(static fn (array $row) => (int) $row['id'], $stmt->fetchAll());
        $created = [];

        foreach ($documentIds as $documentId) {
            if ($this->hasPendingReminder($documentId)) {
                continue;
            }

            $result = $this->workflowRunner->run($this->expiryWorkflowId, 'document.expiring_soon', $documentId);

            foreach ($result['steps'] as $step) {
                if (($step['action'] ?? null) === 'create_record' && isset($step['result']['created_record_id'])) {
                    $created[] = (int) $step['result']['created_record_id'];
                }
            }
        }

        Logger::info('Expiry reminder scan completed', [
            'workspace_id' => $workspaceId,
            'window' => [$from, $to],
            'documents_checked' => count($documentIds),
            'reminders_created' => count($created),
        ]);

        return $created;
    }

    private function hasPendingReminder(int $documentRecordId): bool
    {
        foreach ($this->relations->relatedTo($documentRecordId, 'reminder_for_document') as $reminder) {
            $data = json_decode((string) $reminder['data'], true) ?: [];
            if (($data['status'] ?? null) === 'pending') {
                return true;
            }
        }

        return false;
    }

    /**
     * @return array{status: int, expiry_date: int}
     */
    private function documentFieldIds(): array
    {
        $ids = [];
        foreach ($this->entityMeta->fieldsFor($this->documentEntityId) as $field) {
            $ids[$field['key']] = (int) $field['id'];
        }

        if (! isset($ids['status'], $ids['expiry_date'])) {
            throw new RuntimeException('Document entity is missing required status/expiry_date fields');
        }

        return $ids;
    }
}
