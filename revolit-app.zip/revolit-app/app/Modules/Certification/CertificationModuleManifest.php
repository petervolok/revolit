<?php

declare(strict_types=1);

namespace App\Modules\Certification;

/**
 * Second application case ("Центр сертификации") as a marketplace module
 * manifest, installed through the same ModuleInstallerService as the
 * Banquet module. Entities: client, document (issued certificate),
 * invoice, cash_operation (cash settlements + manager bonuses), and
 * reminder (created automatically by the expiry workflow). Invoices and
 * documents are linked via a real entity_record_relations relation
 * (`invoice_for_document`), not a denormalised copy of data.
 */
final class CertificationModuleManifest
{
    /**
     * @return array<string, mixed>
     */
    public static function manifest(): array
    {
        return [
            'slug' => 'certification-center',
            'name' => 'Центр сертификации',
            'version' => '1.0.0',
            'author' => 'Revolit',
            'description' => 'Выдача сертификатов, счета контрагентам, наличные расчёты и премии, напоминания об истечении срока действия документов.',
            'status' => 'published',
            'roles' => ['director' => 100, 'manager' => 50],
            'entities' => [
                [
                    'slug' => 'client',
                    'name' => 'Контрагент',
                    'description' => 'Клиент центра сертификации',
                    'fields' => [
                        ['key' => 'name', 'label' => 'Наименование', 'type' => 'string', 'is_required' => true],
                        ['key' => 'inn', 'label' => 'ИНН', 'type' => 'string', 'is_required' => false],
                        ['key' => 'phone', 'label' => 'Телефон', 'type' => 'string', 'is_required' => true],
                        ['key' => 'email', 'label' => 'Email', 'type' => 'string', 'is_required' => false, 'validation_rules' => ['email']],
                        ['key' => 'contact_person', 'label' => 'Контактное лицо', 'type' => 'string', 'is_required' => false],
                    ],
                ],
                [
                    'slug' => 'document',
                    'name' => 'Документ',
                    'description' => 'Выданный сертификат/документ',
                    'fields' => [
                        ['key' => 'number', 'label' => 'Номер документа', 'type' => 'string', 'is_required' => true],
                        ['key' => 'client_id', 'label' => 'Контрагент', 'type' => 'relation', 'is_required' => true],
                        ['key' => 'title', 'label' => 'Наименование документа', 'type' => 'string', 'is_required' => true],
                        ['key' => 'issued_date', 'label' => 'Дата выдачи', 'type' => 'date', 'is_required' => true],
                        ['key' => 'expiry_date', 'label' => 'Срок действия до', 'type' => 'date', 'is_required' => true],
                        ['key' => 'status', 'label' => 'Статус', 'type' => 'select', 'is_required' => true, 'options' => ['active', 'expired', 'revoked']],
                    ],
                ],
                [
                    'slug' => 'invoice',
                    'name' => 'Счёт',
                    'description' => 'Выставленный счёт',
                    'fields' => [
                        ['key' => 'number', 'label' => 'Номер счёта', 'type' => 'string', 'is_required' => true],
                        ['key' => 'client_id', 'label' => 'Контрагент', 'type' => 'relation', 'is_required' => true],
                        ['key' => 'amount', 'label' => 'Сумма', 'type' => 'decimal', 'is_required' => true],
                        ['key' => 'status', 'label' => 'Статус оплаты', 'type' => 'select', 'is_required' => true, 'options' => ['unpaid', 'paid']],
                        ['key' => 'payment_type', 'label' => 'Способ оплаты', 'type' => 'select', 'is_required' => true, 'options' => ['cash', 'bank']],
                        ['key' => 'paid_at', 'label' => 'Дата оплаты', 'type' => 'date', 'is_required' => false],
                    ],
                ],
                [
                    'slug' => 'cash_operation',
                    'name' => 'Наличный расчёт / премия',
                    'description' => 'Наличные расчёты по счетам и премии менеджерам',
                    'fields' => [
                        ['key' => 'type', 'label' => 'Тип операции', 'type' => 'select', 'is_required' => true, 'options' => ['cash_receipt', 'manager_bonus']],
                        ['key' => 'invoice_id', 'label' => 'Счёт', 'type' => 'relation', 'is_required' => false],
                        ['key' => 'manager_user_id', 'label' => 'Менеджер', 'type' => 'integer', 'is_required' => true],
                        ['key' => 'amount', 'label' => 'Сумма', 'type' => 'decimal', 'is_required' => true],
                        ['key' => 'operation_date', 'label' => 'Дата', 'type' => 'date', 'is_required' => true],
                        ['key' => 'comment', 'label' => 'Комментарий', 'type' => 'text', 'is_required' => false],
                    ],
                ],
                [
                    'slug' => 'reminder',
                    'name' => 'Напоминание',
                    'description' => 'Напоминание об истечении срока действия документа (создаётся автоматически)',
                    'fields' => [
                        ['key' => 'document_id', 'label' => 'Документ', 'type' => 'relation', 'is_required' => true],
                        ['key' => 'client_id', 'label' => 'Контрагент', 'type' => 'relation', 'is_required' => true],
                        ['key' => 'document_number', 'label' => 'Номер документа', 'type' => 'string', 'is_required' => true],
                        ['key' => 'expiry_date', 'label' => 'Срок действия до', 'type' => 'date', 'is_required' => true],
                        ['key' => 'status', 'label' => 'Статус', 'type' => 'select', 'is_required' => true, 'options' => ['pending', 'done']],
                    ],
                ],
            ],
            'workflows' => [
                [
                    'name' => 'Напоминание об истечении срока документа',
                    'entity_slug' => 'document',
                    'trigger_event' => 'document.expiring_soon',
                    'graph' => [
                        'nodes' => [
                            ['id' => 'trigger', 'type' => 'trigger', 'event' => 'document.expiring_soon'],
                            [
                                'id' => 'create_reminder',
                                'type' => 'action',
                                'action' => 'create_record',
                                'target_entity_slug' => 'reminder',
                                'data' => ['status' => 'pending', 'document_id' => '$source_record_id'],
                                'copy_fields' => [
                                    'client_id' => 'client_id',
                                    'document_number' => 'number',
                                    'expiry_date' => 'expiry_date',
                                ],
                                'link_relation_type' => 'reminder_for_document',
                            ],
                        ],
                        'edges' => [
                            ['from' => 'trigger', 'to' => 'create_reminder'],
                        ],
                    ],
                ],
            ],
        ];
    }
}
