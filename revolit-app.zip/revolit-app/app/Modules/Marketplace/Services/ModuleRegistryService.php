<?php

declare(strict_types=1);

namespace App\Modules\Marketplace\Services;

use App\Core\Logger;
use App\Core\ValidationException;
use PDO;
use RuntimeException;

/**
 * Registers marketplace modules: reusable manifests describing entity
 * types and workflow templates a module contributes. A module is
 * registered once (globally, by slug) and can then be installed into any
 * number of workspaces by ModuleInstallerService.
 *
 * Manifest shape:
 * {
 *   "slug": "banquet-restaurant", "name": "...", "version": "1.0.0",
 *   "author": "...", "description": "...",
 *   "roles": {"director": 100, "manager": 50},
 *   "entities": [{"slug": "client", "name": "Клиент", "description": "...",
 *                 "fields": [{"key":"name","label":"Имя","type":"string","is_required":true}, ...]}, ...],
 *   "workflows": [{"name": "...", "trigger_event": "record.created",
 *                  "entity_slug": "banquet", "graph": {"nodes":[...],"edges":[...]}}]
 * }
 */
final class ModuleRegistryService
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    /**
     * @param array<string, mixed> $manifest
     */
    public function register(array $manifest): int
    {
        $this->assertValidManifest($manifest);

        $now = date('c');
        $existing = $this->pdo->prepare('SELECT id FROM marketplace_modules WHERE slug = :s');
        $existing->execute(['s' => $manifest['slug']]);
        $id = $existing->fetchColumn();

        if ($id !== false) {
            $stmt = $this->pdo->prepare(
                'UPDATE marketplace_modules SET name = :n, version = :v, author = :a, description = :d, status = :st, manifest = :m, updated_at = :u WHERE id = :id'
            );
            $stmt->execute([
                'n' => $manifest['name'],
                'v' => $manifest['version'],
                'a' => $manifest['author'],
                'd' => $manifest['description'] ?? null,
                'st' => $manifest['status'] ?? 'published',
                'm' => json_encode($manifest, JSON_UNESCAPED_UNICODE),
                'u' => $now,
                'id' => $id,
            ]);

            Logger::info('Marketplace module re-registered', ['module_id' => $id, 'slug' => $manifest['slug']]);

            return (int) $id;
        }

        $stmt = $this->pdo->prepare(
            'INSERT INTO marketplace_modules (slug, name, version, author, description, status, manifest, created_at, updated_at)
             VALUES (:s, :n, :v, :a, :d, :st, :m, :c, :u)'
        );
        $stmt->execute([
            's' => $manifest['slug'],
            'n' => $manifest['name'],
            'v' => $manifest['version'],
            'a' => $manifest['author'],
            'd' => $manifest['description'] ?? null,
            'st' => $manifest['status'] ?? 'published',
            'm' => json_encode($manifest, JSON_UNESCAPED_UNICODE),
            'c' => $now,
            'u' => $now,
        ]);

        $id = (int) $this->pdo->lastInsertId();
        Logger::info('Marketplace module registered', ['module_id' => $id, 'slug' => $manifest['slug']]);

        return $id;
    }

    public function findBySlug(string $slug): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM marketplace_modules WHERE slug = :s');
        $stmt->execute(['s' => $slug]);
        $row = $stmt->fetch();

        if ($row === false) {
            throw new RuntimeException("Marketplace module '{$slug}' not found");
        }

        return $row;
    }

    public function find(int $id): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM marketplace_modules WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();

        if ($row === false) {
            throw new RuntimeException("Marketplace module {$id} not found");
        }

        return $row;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listPublished(): array
    {
        return $this->pdo->query("SELECT * FROM marketplace_modules WHERE status = 'published' ORDER BY name ASC")->fetchAll();
    }

    /**
     * @param array<string, mixed> $manifest
     */
    private function assertValidManifest(array $manifest): void
    {
        $errors = [];

        foreach (['slug', 'name', 'version', 'author'] as $required) {
            if (empty($manifest[$required]) || ! is_string($manifest[$required])) {
                $errors['manifest'][] = "Manifest field '{$required}' is required.";
            }
        }

        if (! isset($manifest['entities']) || ! is_array($manifest['entities']) || $manifest['entities'] === []) {
            $errors['manifest'][] = 'Manifest must define at least one entity.';
        } else {
            foreach ($manifest['entities'] as $entity) {
                if (empty($entity['slug']) || empty($entity['name']) || empty($entity['fields'])) {
                    $errors['manifest'][] = 'Each entity definition needs slug, name and fields.';
                    break;
                }
            }
        }

        if (isset($manifest['workflows']) && ! is_array($manifest['workflows'])) {
            $errors['manifest'][] = 'workflows must be an array when present.';
        }

        if ($errors !== []) {
            throw new ValidationException($errors);
        }
    }
}
