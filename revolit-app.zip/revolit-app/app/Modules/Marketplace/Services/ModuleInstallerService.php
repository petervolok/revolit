<?php

declare(strict_types=1);

namespace App\Modules\Marketplace\Services;

use App\Core\Database;
use App\Core\Logger;
use App\Modules\EntityBuilder\Services\EntityService;
use App\Modules\EntityBuilder\Services\RoleService;
use App\Modules\WorkflowEngine\Services\WorkflowService;
use PDO;
use RuntimeException;

/**
 * Turns a registered marketplace module's manifest into real, working
 * workspace data: it calls the very same EntityService/WorkflowService the
 * rest of the app uses to build entity types and workflows by hand, so
 * "installing a module" is not a mock - it is a real, auditable sequence
 * of the same core service calls a developer would make manually. What it
 * created is recorded on module_installations so uninstall() can undo
 * exactly that, and nothing else.
 */
final class ModuleInstallerService
{
    public function __construct(
        private readonly PDO $pdo,
        private readonly ModuleRegistryService $registry,
        private readonly EntityService $entities,
        private readonly WorkflowService $workflows,
        private readonly RoleService $roles,
    ) {
    }

    /**
     * @return array{installation_id: int, workspace_id: int, roles: array<string, int>, entities: array<string, int>, workflows: array<string, int>}
     */
    public function install(int $moduleId, int $workspaceId): array
    {
        $module = $this->registry->find($moduleId);
        $manifest = json_decode((string) $module['manifest'], true) ?: [];

        // Not wrapped in a single outer transaction: each step below
        // (createEntity, workflow create) already commits its own
        // transaction via EntityService/WorkflowService, and this
        // connection (PDO/SQLite) does not support nested transactions.
        return (function () use ($moduleId, $workspaceId, $manifest) {
            $roles = $this->roles->ensureRoles($manifest['roles'] ?? []);

            $entitySlugToId = [];
            foreach ($manifest['entities'] as $entityDef) {
                $entitySlugToId[$entityDef['slug']] = $this->entities->createEntity(
                    $workspaceId,
                    $entityDef['name'],
                    $entityDef['slug'],
                    $entityDef['description'] ?? null,
                    $entityDef['fields']
                );
            }

            $workflowNameToId = [];
            foreach ($manifest['workflows'] ?? [] as $workflowDef) {
                $entitySlug = $workflowDef['entity_slug'] ?? null;
                $entityId = $entitySlug !== null ? ($entitySlugToId[$entitySlug] ?? null) : null;

                if ($entitySlug !== null && $entityId === null) {
                    throw new RuntimeException("Workflow '{$workflowDef['name']}' references unknown entity slug '{$entitySlug}'");
                }

                $workflowNameToId[$workflowDef['name']] = $this->workflows->create(
                    $workspaceId,
                    $entityId,
                    $workflowDef['name'],
                    $workflowDef['trigger_event'],
                    $this->resolveGraphEntitySlugs($workflowDef['graph'], $entitySlugToId)
                );
            }

            $now = date('c');
            $stmt = $this->pdo->prepare(
                'INSERT INTO module_installations (module_id, workspace_id, status, created_entities, created_workflows, created_roles, installed_at)
                 VALUES (:m, :w, :st, :e, :wf, :r, :i)'
            );
            $stmt->execute([
                'm' => $moduleId,
                'w' => $workspaceId,
                'st' => 'active',
                'e' => json_encode($entitySlugToId, JSON_UNESCAPED_UNICODE),
                'wf' => json_encode($workflowNameToId, JSON_UNESCAPED_UNICODE),
                'r' => json_encode($roles, JSON_UNESCAPED_UNICODE),
                'i' => $now,
            ]);
            $installationId = (int) $this->pdo->lastInsertId();

            Logger::info('Marketplace module installed', [
                'module_id' => $moduleId,
                'workspace_id' => $workspaceId,
                'installation_id' => $installationId,
                'entities' => $entitySlugToId,
                'workflows' => $workflowNameToId,
            ]);

            return [
                'installation_id' => $installationId,
                'workspace_id' => $workspaceId,
                'roles' => $roles,
                'entities' => $entitySlugToId,
                'workflows' => $workflowNameToId,
            ];
        })();
    }

    /**
     * A manifest cannot know the real entity ids its own entities will get
     * in a particular workspace, so action nodes reference other module
     * entities by slug (`target_entity_slug`). Here, at install time, those
     * slugs are resolved to the just-created real entity ids before the
     * graph is persisted - the stored workflow.graph then contains only
     * concrete ids, exactly like a hand-built workflow would.
     *
     * @param array{nodes: array<int, array<string, mixed>>, edges: array<int, array<string, mixed>>} $graph
     * @param array<string, int> $entitySlugToId
     * @return array{nodes: array<int, array<string, mixed>>, edges: array<int, array<string, mixed>>}
     */
    private function resolveGraphEntitySlugs(array $graph, array $entitySlugToId): array
    {
        foreach ($graph['nodes'] as &$node) {
            if (! isset($node['target_entity_slug'])) {
                continue;
            }

            $slug = $node['target_entity_slug'];
            if (! isset($entitySlugToId[$slug])) {
                throw new RuntimeException("Workflow node references unknown entity slug '{$slug}'");
            }

            $node['target_entity_id'] = $entitySlugToId[$slug];
            unset($node['target_entity_slug']);
        }
        unset($node);

        return $graph;
    }

    public function uninstall(int $installationId): void
    {
        $stmt = $this->pdo->prepare('SELECT * FROM module_installations WHERE id = :id');
        $stmt->execute(['id' => $installationId]);
        $installation = $stmt->fetch();

        if ($installation === false) {
            throw new RuntimeException("Module installation {$installationId} not found");
        }

        if ($installation['status'] === 'uninstalled') {
            Logger::warning('Attempted to uninstall an already-uninstalled module installation', ['installation_id' => $installationId]);

            return;
        }

        Database::transaction(function () use ($installation, $installationId) {
            $workflowIds = array_values(json_decode((string) $installation['created_workflows'], true) ?: []);
            foreach ($workflowIds as $workflowId) {
                $this->pdo->prepare('DELETE FROM workflows WHERE id = :id')->execute(['id' => (int) $workflowId]);
            }

            $entityIds = array_values(json_decode((string) $installation['created_entities'], true) ?: []);
            foreach ($entityIds as $entityId) {
                $this->pdo->prepare('DELETE FROM entities WHERE id = :id')->execute(['id' => (int) $entityId]);
            }

            $this->pdo->prepare("UPDATE module_installations SET status = 'uninstalled', uninstalled_at = :u WHERE id = :id")
                ->execute(['u' => date('c'), 'id' => $installationId]);
        });

        Logger::info('Marketplace module uninstalled', ['installation_id' => $installationId]);
    }
}
