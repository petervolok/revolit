<?php

declare(strict_types=1);

namespace App\Modules\WorkflowEngine\Services;

use App\Core\Logger;
use App\Core\ValidationException;
use App\Core\Validator;
use PDO;

final class WorkflowService
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    /**
     * @param array{nodes: array<int, array<string, mixed>>, edges: array<int, array<string, mixed>>} $graph
     */
    public function create(int $workspaceId, ?int $entityId, string $name, string $triggerEvent, array $graph): int
    {
        Validator::make(
            ['name' => $name, 'trigger_event' => $triggerEvent],
            ['name' => 'required|string|max:120', 'trigger_event' => 'required|string|max:60']
        )->validate();

        if (! isset($graph['nodes']) || ! isset($graph['edges'])) {
            throw new ValidationException(['graph' => ['Workflow graph must contain nodes and edges.']]);
        }

        $now = date('c');
        $stmt = $this->pdo->prepare(
            'INSERT INTO workflows (workspace_id, entity_id, name, trigger_event, graph, is_active, created_at, updated_at)
             VALUES (:w, :e, :n, :t, :g, 1, :c, :u)'
        );
        $stmt->execute([
            'w' => $workspaceId,
            'e' => $entityId,
            'n' => $name,
            't' => $triggerEvent,
            'g' => json_encode($graph, JSON_UNESCAPED_UNICODE),
            'c' => $now,
            'u' => $now,
        ]);

        $id = (int) $this->pdo->lastInsertId();
        Logger::info('Workflow created', ['workflow_id' => $id, 'name' => $name]);

        return $id;
    }
}
