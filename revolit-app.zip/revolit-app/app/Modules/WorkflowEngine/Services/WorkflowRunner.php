<?php

declare(strict_types=1);

namespace App\Modules\WorkflowEngine\Services;

use App\Core\Database;
use App\Core\Logger;
use App\Modules\WorkflowEngine\Contracts\AgentExecutorInterface;
use PDO;
use RuntimeException;

/**
 * Executes a workflow graph (nodes + edges JSON) against a real
 * entity_records row for a given trigger event. Supports trigger,
 * condition (branching) and action node types. No step is mocked: actions
 * mutate entity_records for real and condition branches are evaluated
 * against the record's actual stored data.
 */
final class WorkflowRunner
{
    /** @var array<int, AgentExecutorInterface> */
    private array $executors;

    public function __construct(private readonly PDO $pdo, AgentExecutorInterface ...$executors)
    {
        $this->executors = $executors;
    }

    /**
     * @return array<string, mixed> Execution log entries
     */
    public function run(int $workflowId, string $event, int $entityRecordId): array
    {
        $workflow = $this->loadWorkflow($workflowId);

        if ($workflow['is_active'] == 0) {
            throw new RuntimeException("Workflow {$workflowId} is inactive");
        }

        $graph = json_decode((string) $workflow['graph'], true);
        if (! is_array($graph) || ! isset($graph['nodes'], $graph['edges'])) {
            throw new RuntimeException("Workflow {$workflowId} has an invalid graph definition");
        }

        $nodesById = [];
        foreach ($graph['nodes'] as $node) {
            $nodesById[$node['id']] = $node;
        }

        $triggerNode = null;
        foreach ($graph['nodes'] as $node) {
            if ($node['type'] === 'trigger' && $node['event'] === $event) {
                $triggerNode = $node;
                break;
            }
        }

        if ($triggerNode === null) {
            Logger::info('Workflow run skipped: no matching trigger', ['workflow_id' => $workflowId, 'event' => $event]);

            return ['status' => 'skipped', 'reason' => 'no matching trigger', 'steps' => []];
        }

        $steps = [];
        $status = 'completed';

        try {
            $this->traverse($triggerNode['id'], $nodesById, $graph['edges'], $entityRecordId, $steps);
        } catch (\Throwable $exception) {
            $status = 'failed';
            $steps[] = ['error' => $exception->getMessage()];
            Logger::error('Workflow run failed', ['workflow_id' => $workflowId, 'error' => $exception->getMessage()]);
        }

        $runId = $this->persistRun($workflowId, $entityRecordId, $status, $steps);

        return ['status' => $status, 'run_id' => $runId, 'steps' => $steps];
    }

    /**
     * @param array<string, array<string, mixed>> $nodesById
     * @param array<int, array<string, mixed>> $edges
     * @param array<int, array<string, mixed>> $steps
     */
    private function traverse(string $nodeId, array $nodesById, array $edges, int $recordId, array &$steps): void
    {
        $node = $nodesById[$nodeId] ?? null;
        if ($node === null) {
            return;
        }

        $branch = null;

        if ($node['type'] === 'trigger') {
            $steps[] = ['node' => $nodeId, 'type' => 'trigger', 'event' => $node['event']];
        } elseif ($node['type'] === 'condition') {
            $result = $this->evaluateCondition($node, $recordId);
            $branch = $result ? 'true' : 'false';
            $steps[] = ['node' => $nodeId, 'type' => 'condition', 'result' => $result];
        } elseif ($node['type'] === 'action') {
            $result = $this->executeAction($node, $recordId);
            $steps[] = ['node' => $nodeId, 'type' => 'action', 'action' => $node['action'], 'result' => $result];
        } else {
            throw new RuntimeException("Unknown node type '{$node['type']}' at node {$nodeId}");
        }

        foreach ($edges as $edge) {
            if ($edge['from'] !== $nodeId) {
                continue;
            }

            if ($branch !== null && ($edge['branch'] ?? null) !== $branch) {
                continue;
            }

            $this->traverse($edge['to'], $nodesById, $edges, $recordId, $steps);
        }
    }

    /**
     * @param array<string, mixed> $node
     */
    private function evaluateCondition(array $node, int $recordId): bool
    {
        $stmt = $this->pdo->prepare('SELECT data FROM entity_records WHERE id = :id');
        $stmt->execute(['id' => $recordId]);
        $row = $stmt->fetch();

        if ($row === false) {
            throw new RuntimeException("Record {$recordId} not found while evaluating condition");
        }

        $data = json_decode((string) $row['data'], true) ?: [];
        $actual = $data[$node['field']] ?? null;
        $expected = $node['value'] ?? null;

        return match ($node['operator']) {
            'equals' => (string) $actual === (string) $expected,
            'not_equals' => (string) $actual !== (string) $expected,
            'greater_than' => is_numeric($actual) && (float) $actual > (float) $expected,
            'less_than' => is_numeric($actual) && (float) $actual < (float) $expected,
            default => throw new RuntimeException("Unknown condition operator '{$node['operator']}'"),
        };
    }

    /**
     * @param array<string, mixed> $node
     * @return array<string, mixed>
     */
    private function executeAction(array $node, int $recordId): array
    {
        return match ($node['action']) {
            'set_field' => $this->setField($recordId, $node['field'], $node['value']),
            'assign' => $this->assign($recordId, $node),
            'create_record' => $this->createRecord($recordId, $node),
            default => throw new RuntimeException("Unknown action '{$node['action']}'"),
        };
    }

    /**
     * Creates a new entity_records row derived from the triggering record -
     * real business logic for steps like "create an expiry reminder for
     * this document", not a mocked side effect. The new record is linked
     * back to the source record via entity_record_relations when
     * `link_relation_type` is set.
     *
     * Node shape: {action:"create_record", target_entity_id:int,
     *   data?: {...static field values...},
     *   copy_fields?: {targetFieldKey: sourceFieldKey, ...},
     *   link_relation_type?: string}
     *
     * @param array<string, mixed> $node
     * @return array<string, mixed>
     */
    private function createRecord(int $sourceRecordId, array $node): array
    {
        if (! isset($node['target_entity_id'])) {
            throw new RuntimeException('create_record action requires target_entity_id');
        }

        $stmt = $this->pdo->prepare('SELECT workspace_id, owner_id, data FROM entity_records WHERE id = :id');
        $stmt->execute(['id' => $sourceRecordId]);
        $source = $stmt->fetch();

        if ($source === false) {
            throw new RuntimeException("Record {$sourceRecordId} not found while executing create_record");
        }

        $sourceData = json_decode((string) $source['data'], true) ?: [];
        $data = $node['data'] ?? [];

        foreach ($node['copy_fields'] ?? [] as $targetKey => $sourceKey) {
            $data[$targetKey] = $sourceData[$sourceKey] ?? null;
        }

        // "$source_record_id" is a placeholder resolved to the id of the
        // record that triggered this action, e.g. so a reminder record can
        // store which document it was created for.
        foreach ($data as $key => $value) {
            if ($value === '$source_record_id') {
                $data[$key] = $sourceRecordId;
            }
        }

        $now = date('c');
        $insert = $this->pdo->prepare(
            'INSERT INTO entity_records (entity_id, workspace_id, owner_id, is_owner_only, data, created_at, updated_at)
             VALUES (:e, :w, :o, 0, :d, :c, :u)'
        );
        $insert->execute([
            'e' => (int) $node['target_entity_id'],
            'w' => (int) $source['workspace_id'],
            'o' => $source['owner_id'],
            'd' => json_encode($data, JSON_UNESCAPED_UNICODE),
            'c' => $now,
            'u' => $now,
        ]);
        $newRecordId = (int) $this->pdo->lastInsertId();

        if (! empty($node['link_relation_type'])) {
            $relate = $this->pdo->prepare(
                'INSERT INTO entity_record_relations (from_record_id, to_record_id, relation_type, created_at) VALUES (:f, :t, :r, :c)'
            );
            $relate->execute([
                'f' => $sourceRecordId,
                't' => $newRecordId,
                'r' => (string) $node['link_relation_type'],
                'c' => $now,
            ]);
        }

        Logger::info('Workflow action create_record executed', [
            'source_record_id' => $sourceRecordId,
            'created_record_id' => $newRecordId,
            'target_entity_id' => $node['target_entity_id'],
        ]);

        return ['created_record_id' => $newRecordId, 'target_entity_id' => (int) $node['target_entity_id']];
    }

    private function setField(int $recordId, string $field, mixed $value): array
    {
        $stmt = $this->pdo->prepare('SELECT data FROM entity_records WHERE id = :id');
        $stmt->execute(['id' => $recordId]);
        $row = $stmt->fetch();
        $data = $row ? (json_decode((string) $row['data'], true) ?: []) : [];
        $data[$field] = $value;

        $update = $this->pdo->prepare('UPDATE entity_records SET data = :d, updated_at = :u WHERE id = :id');
        $update->execute(['d' => json_encode($data, JSON_UNESCAPED_UNICODE), 'u' => date('c'), 'id' => $recordId]);

        Logger::info('Workflow action set_field executed', ['record_id' => $recordId, 'field' => $field, 'value' => $value]);

        return ['field' => $field, 'value' => $value];
    }

    /**
     * @param array<string, mixed> $node
     */
    private function assign(int $recordId, array $node): array
    {
        $assigneeType = $node['assignee_type'] ?? 'human';

        foreach ($this->executors as $executor) {
            if ($executor->supports($assigneeType)) {
                return $executor->execute([
                    'entity_record_id' => $recordId,
                    'action' => 'assign',
                    'payload' => $node,
                ]);
            }
        }

        throw new RuntimeException("No executor registered for assignee type '{$assigneeType}'");
    }

    private function loadWorkflow(int $workflowId): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM workflows WHERE id = :id');
        $stmt->execute(['id' => $workflowId]);
        $row = $stmt->fetch();

        if ($row === false) {
            throw new RuntimeException("Workflow {$workflowId} not found");
        }

        return $row;
    }

    /**
     * @param array<int, array<string, mixed>> $steps
     */
    private function persistRun(int $workflowId, int $recordId, string $status, array $steps): int
    {
        $now = date('c');
        $stmt = $this->pdo->prepare(
            'INSERT INTO workflow_runs (workflow_id, entity_record_id, status, log, created_at, updated_at) VALUES (:w, :r, :s, :l, :c, :u)'
        );
        $stmt->execute([
            'w' => $workflowId,
            'r' => $recordId,
            's' => $status,
            'l' => json_encode($steps, JSON_UNESCAPED_UNICODE),
            'c' => $now,
            'u' => $now,
        ]);

        return (int) $this->pdo->lastInsertId();
    }
}
