<?php

declare(strict_types=1);

namespace App\Modules\WorkflowEngine\Executors;

use App\Core\Logger;
use App\Modules\WorkflowEngine\Contracts\AgentExecutorInterface;
use App\Modules\WorkflowEngine\Contracts\NotImplementedException;

/**
 * Deliberate module boundary: no real LLM call is wired up in this
 * iteration. Any attempt to assign a step to an AI agent is logged and
 * rejected explicitly rather than silently faking a result, so callers
 * cannot mistake this for a working integration.
 */
final class AiAgentExecutor implements AgentExecutorInterface
{
    public function supports(string $assigneeType): bool
    {
        return $assigneeType === 'ai_agent';
    }

    public function execute(array $context): array
    {
        Logger::warning('AI agent execution requested but not implemented', $context);

        throw new NotImplementedException(
            'AiAgentExecutor has no LLM integration in this iteration. ' .
            'Assign this step to a human executor instead, or implement a concrete LLM-backed executor.'
        );
    }
}
