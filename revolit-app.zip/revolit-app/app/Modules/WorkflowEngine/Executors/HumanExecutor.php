<?php

declare(strict_types=1);

namespace App\Modules\WorkflowEngine\Executors;

use App\Core\Logger;
use App\Modules\WorkflowEngine\Contracts\AgentExecutorInterface;
use PDO;

/**
 * Default assignment executor: records the human assignment on the entity
 * record itself (assigned_user_id inside the JSON payload) via a direct,
 * real database write — this is the working default path of the engine.
 */
final class HumanExecutor implements AgentExecutorInterface
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    public function supports(string $assigneeType): bool
    {
        return $assigneeType === 'human';
    }

    public function execute(array $context): array
    {
        $recordId = (int) $context['entity_record_id'];

        $stmt = $this->pdo->prepare('SELECT data, owner_id FROM entity_records WHERE id = :id');
        $stmt->execute(['id' => $recordId]);
        $row = $stmt->fetch();

        if ($row === false) {
            throw new \RuntimeException("Cannot assign: entity record {$recordId} not found");
        }

        // The workflow step may specify an explicit user_id; otherwise the
        // record's owner (e.g. the manager who created it) is assigned.
        $userId = isset($context['payload']['user_id']) ? (int) $context['payload']['user_id'] : (int) $row['owner_id'];

        $data = json_decode((string) $row['data'], true) ?: [];
        $data['assigned_user_id'] = $userId;

        $update = $this->pdo->prepare('UPDATE entity_records SET data = :d, updated_at = :u WHERE id = :id');
        $update->execute(['d' => json_encode($data, JSON_UNESCAPED_UNICODE), 'u' => date('c'), 'id' => $recordId]);

        Logger::info('Workflow step assigned to human', ['record_id' => $recordId, 'user_id' => $userId]);

        return ['assigned_to' => 'human', 'user_id' => $userId];
    }
}
