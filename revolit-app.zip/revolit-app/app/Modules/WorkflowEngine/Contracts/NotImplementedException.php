<?php

declare(strict_types=1);

namespace App\Modules\WorkflowEngine\Contracts;

use RuntimeException;

/**
 * Thrown by executors that represent a deliberately unimplemented module
 * boundary (e.g. AiAgentExecutor: no real LLM integration exists yet).
 * This is NOT a stand-in for missing business logic — the human-assignment
 * path (HumanExecutor) is fully implemented and covered by tests. See
 * ARCHITECTURE.md, "AiAgentExecutor — осознанная граница модуля".
 */
final class NotImplementedException extends RuntimeException
{
}
