<?php

declare(strict_types=1);

namespace App\Modules\WorkflowEngine\Contracts;

/**
 * A workflow "action" step can be assigned to a human or to an AI agent.
 * Both assignment targets execute through this contract so the workflow
 * engine never needs to know which kind of executor handled a step.
 */
interface AgentExecutorInterface
{
    /**
     * @param array<string, mixed> $context Includes at least entity_record_id, action, payload
     * @return array<string, mixed> Result data to attach to the workflow run log
     */
    public function execute(array $context): array;

    public function supports(string $assigneeType): bool;
}
