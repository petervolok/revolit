<?php

declare(strict_types=1);

namespace App\Modules\EntityBuilder\Models;

final class User
{
    public function __construct(
        public readonly int $id,
        public readonly int $workspaceId,
        public readonly int $roleId,
        public readonly string $name,
        public readonly string $email,
        public readonly string $roleName,
        public readonly int $roleLevel,
    ) {
    }

    public static function fromRow(array $row): self
    {
        return new self(
            id: (int) $row['id'],
            workspaceId: (int) $row['workspace_id'],
            roleId: (int) $row['role_id'],
            name: (string) $row['name'],
            email: (string) $row['email'],
            roleName: (string) $row['role_name'],
            roleLevel: (int) $row['role_level'],
        );
    }

    public function isDirector(): bool
    {
        return $this->roleName === 'director';
    }
}
