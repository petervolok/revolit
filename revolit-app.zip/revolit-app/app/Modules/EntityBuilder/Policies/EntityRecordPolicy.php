<?php

declare(strict_types=1);

namespace App\Modules\EntityBuilder\Policies;

use App\Modules\EntityBuilder\Models\User;

/**
 * Role-aware access rules for entity records (mirrors a Laravel Policy/Gate).
 *
 * Rule: records flagged is_owner_only are visible to their creator and to
 * users whose role is "director" (role level >= DIRECTOR_LEVEL). Regular
 * managers/employees cannot see other people's owner-only records.
 */
final class EntityRecordPolicy
{
    public const DIRECTOR_LEVEL = 100;

    public function view(User $user, array $record): bool
    {
        if ((int) $record['workspace_id'] !== $user->workspaceId) {
            return false;
        }

        if ((int) ($record['is_owner_only'] ?? 0) === 0) {
            return true;
        }

        if ($user->roleLevel >= self::DIRECTOR_LEVEL) {
            return true;
        }

        return (int) ($record['owner_id'] ?? 0) === $user->id;
    }

    public function update(User $user, array $record): bool
    {
        return $this->view($user, $record);
    }

    public function delete(User $user, array $record): bool
    {
        return $user->roleLevel >= self::DIRECTOR_LEVEL || (int) ($record['owner_id'] ?? 0) === $user->id;
    }
}
