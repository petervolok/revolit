<?php

declare(strict_types=1);

namespace App\Modules\EntityBuilder\Services;

use App\Core\Database;
use App\Core\Logger;
use App\Core\ValidationException;
use App\Core\Validator;
use App\Modules\EntityBuilder\Models\User;
use App\Modules\EntityBuilder\Policies\EntityRecordPolicy;
use PDO;
use RuntimeException;

/**
 * CRUD for entity_records with dynamic, metadata-driven validation.
 *
 * Values are persisted twice on write: once as a JSON blob on entity_records
 * (fast whole-record reads) and once per-field in entity_record_values (an
 * EAV projection enabling indexed lookups, e.g. "banquets on date X"). See
 * ARCHITECTURE.md for the rationale.
 */
final class EntityRecordService
{
    public function __construct(
        private readonly PDO $pdo,
        private readonly EntityService $entities,
        private readonly EntityRecordPolicy $policy = new EntityRecordPolicy()
    ) {
    }

    /**
     * @param array<string, mixed> $values
     */
    public function create(int $entityId, int $workspaceId, User $actor, array $values, bool $isOwnerOnly = false): int
    {
        $fields = $this->entities->fieldsFor($entityId);
        if ($fields === []) {
            throw new RuntimeException("Entity {$entityId} has no fields defined");
        }

        $validated = $this->validateValues($fields, $values);

        return Database::transaction(function (PDO $pdo) use ($entityId, $workspaceId, $actor, $validated, $isOwnerOnly, $fields) {
            $now = date('c');
            $stmt = $pdo->prepare(
                'INSERT INTO entity_records (entity_id, workspace_id, owner_id, is_owner_only, data, created_at, updated_at)
                 VALUES (:e, :w, :o, :io, :d, :c, :u)'
            );
            $stmt->execute([
                'e' => $entityId,
                'w' => $workspaceId,
                'o' => $actor->id,
                'io' => $isOwnerOnly ? 1 : 0,
                'd' => json_encode($validated, JSON_UNESCAPED_UNICODE),
                'c' => $now,
                'u' => $now,
            ]);
            $recordId = (int) $pdo->lastInsertId();

            $this->syncEavValues($pdo, $recordId, $fields, $validated);

            Logger::info('Entity record created', ['entity_id' => $entityId, 'record_id' => $recordId, 'owner_id' => $actor->id]);

            return $recordId;
        });
    }

    /**
     * @param array<string, mixed> $values
     */
    public function update(int $recordId, User $actor, array $values): void
    {
        $record = $this->find($recordId);

        if (! $this->policy->update($actor, $record)) {
            Logger::warning('Unauthorized record update attempt', ['record_id' => $recordId, 'user_id' => $actor->id]);
            throw new RuntimeException('You are not allowed to update this record.');
        }

        $fields = $this->entities->fieldsFor((int) $record['entity_id']);
        $current = json_decode((string) $record['data'], true) ?: [];
        $merged = array_merge($current, $values);
        $validated = $this->validateValues($fields, $merged);

        Database::transaction(function (PDO $pdo) use ($recordId, $validated, $fields) {
            $stmt = $pdo->prepare('UPDATE entity_records SET data = :d, updated_at = :u WHERE id = :id');
            $stmt->execute(['d' => json_encode($validated, JSON_UNESCAPED_UNICODE), 'u' => date('c'), 'id' => $recordId]);
            $this->syncEavValues($pdo, $recordId, $fields, $validated);
        });

        Logger::info('Entity record updated', ['record_id' => $recordId]);
    }

    public function find(int $recordId): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM entity_records WHERE id = :id');
        $stmt->execute(['id' => $recordId]);
        $row = $stmt->fetch();

        if ($row === false) {
            throw new RuntimeException("Record {$recordId} not found");
        }

        return $row;
    }

    /**
     * Records visible to the given actor for an entity, honouring owner-only visibility.
     *
     * @return array<int, array<string, mixed>>
     */
    public function listVisibleFor(int $entityId, User $actor): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM entity_records WHERE entity_id = :e AND workspace_id = :w ORDER BY id ASC');
        $stmt->execute(['e' => $entityId, 'w' => $actor->workspaceId]);

        $rows = $stmt->fetchAll();

        return array_values(array_filter($rows, fn (array $row) => $this->policy->view($actor, $row)));
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     * @return array<string, mixed>
     */
    private function validateValues(array $fields, array $values): array
    {
        $rules = [];
        $labels = [];

        foreach ($fields as $field) {
            $ruleParts = [];
            $ruleParts[] = ! empty($field['is_required']) ? 'required' : 'nullable';
            $ruleParts[] = match ($field['type']) {
                'integer' => 'integer',
                'decimal' => 'numeric',
                'boolean' => 'boolean',
                'date' => 'date',
                'select' => 'string',
                'relation' => 'integer',
                default => 'string',
            };

            if ($field['type'] === 'select' && $field['options']) {
                $options = json_decode((string) $field['options'], true) ?: [];
                if ($options !== []) {
                    $ruleParts[] = 'in:' . implode(',', $options);
                }
            }

            if ($field['validation_rules']) {
                $extra = json_decode((string) $field['validation_rules'], true) ?: [];
                $ruleParts = array_merge($ruleParts, $extra);
            }

            $rules[$field['key']] = implode('|', $ruleParts);
            $labels[$field['key']] = $field['label'];
        }

        $validator = Validator::make($values, $rules, $labels);

        try {
            $validated = $validator->validate();
        } catch (ValidationException $exception) {
            Logger::warning('Entity record validation failed', ['errors' => $exception->errors()]);
            throw $exception;
        }

        // Preserve values not covered by rules is intentionally disallowed:
        // only declared fields are persisted, enforcing the entity schema.
        return $validated;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     */
    private function syncEavValues(PDO $pdo, int $recordId, array $fields, array $values): void
    {
        $pdo->prepare('DELETE FROM entity_record_values WHERE entity_record_id = :id')->execute(['id' => $recordId]);

        $stmt = $pdo->prepare(
            'INSERT INTO entity_record_values (entity_record_id, entity_field_id, value, created_at, updated_at) VALUES (:r, :f, :v, :c, :u)'
        );
        $now = date('c');

        foreach ($fields as $field) {
            if (! array_key_exists($field['key'], $values) || $values[$field['key']] === null) {
                continue;
            }

            $value = $values[$field['key']];
            $stmt->execute([
                'r' => $recordId,
                'f' => $field['id'],
                'v' => is_bool($value) ? ($value ? '1' : '0') : (string) $value,
                'c' => $now,
                'u' => $now,
            ]);
        }
    }
}
