<?php

declare(strict_types=1);

namespace App\Modules\EntityBuilder\Services;

use App\Core\Logger;
use PDO;
use RuntimeException;

/**
 * Real relations between entity_records, possibly of different entity
 * types (e.g. an "invoice" record linked to the "document" record it was
 * issued for). Deliberately generic and typed by relation_type so any
 * module can express its own semantics without new tables - the same
 * pattern the Entity Builder already uses for entities/fields.
 */
final class EntityRecordRelationService
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    public function relate(int $fromRecordId, int $toRecordId, string $relationType): int
    {
        if (! $this->recordExists($fromRecordId) || ! $this->recordExists($toRecordId)) {
            throw new RuntimeException('Cannot relate: one of the records does not exist');
        }

        $stmt = $this->pdo->prepare(
            'INSERT INTO entity_record_relations (from_record_id, to_record_id, relation_type, created_at) VALUES (:f, :t, :r, :c)'
        );
        $stmt->execute([
            'f' => $fromRecordId,
            't' => $toRecordId,
            'r' => $relationType,
            'c' => date('c'),
        ]);

        $id = (int) $this->pdo->lastInsertId();

        Logger::info('Entity records related', [
            'relation_id' => $id,
            'from' => $fromRecordId,
            'to' => $toRecordId,
            'type' => $relationType,
        ]);

        return $id;
    }

    /**
     * Records that $fromRecordId points to, optionally filtered by type.
     *
     * @return array<int, array<string, mixed>>
     */
    public function relatedTo(int $fromRecordId, ?string $relationType = null): array
    {
        $sql = 'SELECT er.*, rel.relation_type AS relation_type, rel.id AS relation_id
                FROM entity_record_relations rel
                JOIN entity_records er ON er.id = rel.to_record_id
                WHERE rel.from_record_id = :id';
        $params = ['id' => $fromRecordId];

        if ($relationType !== null) {
            $sql .= ' AND rel.relation_type = :t';
            $params['t'] = $relationType;
        }

        $stmt = $this->pdo->prepare($sql . ' ORDER BY rel.id ASC');
        $stmt->execute($params);

        return $stmt->fetchAll();
    }

    /**
     * Records that point to $toRecordId, optionally filtered by type.
     *
     * @return array<int, array<string, mixed>>
     */
    public function relatedFrom(int $toRecordId, ?string $relationType = null): array
    {
        $sql = 'SELECT er.*, rel.relation_type AS relation_type, rel.id AS relation_id
                FROM entity_record_relations rel
                JOIN entity_records er ON er.id = rel.from_record_id
                WHERE rel.to_record_id = :id';
        $params = ['id' => $toRecordId];

        if ($relationType !== null) {
            $sql .= ' AND rel.relation_type = :t';
            $params['t'] = $relationType;
        }

        $stmt = $this->pdo->prepare($sql . ' ORDER BY rel.id ASC');
        $stmt->execute($params);

        return $stmt->fetchAll();
    }

    public function unrelate(int $relationId): void
    {
        $this->pdo->prepare('DELETE FROM entity_record_relations WHERE id = :id')->execute(['id' => $relationId]);
        Logger::info('Entity record relation removed', ['relation_id' => $relationId]);
    }

    private function recordExists(int $recordId): bool
    {
        $stmt = $this->pdo->prepare('SELECT 1 FROM entity_records WHERE id = :id');
        $stmt->execute(['id' => $recordId]);

        return $stmt->fetchColumn() !== false;
    }
}
