<?php

declare(strict_types=1);

namespace App\Modules\EntityBuilder\Services;

use App\Core\Logger;
use App\Core\ValidationException;
use App\Core\Validator;
use PDO;
use RuntimeException;

/**
 * Handles definition of entity types ("Банкет", "Клиент", ...) and their
 * fields. This is the "no-code" metadata layer: an entity's shape is fully
 * described by rows in entity_fields, driving both validation and the
 * dynamic record storage below (EntityRecordService).
 */
final class EntityService
{
    private const VALID_FIELD_TYPES = ['string', 'text', 'integer', 'decimal', 'boolean', 'date', 'select', 'relation'];

    public function __construct(private readonly PDO $pdo)
    {
    }

    /**
     * @param array<int, array{key: string, label: string, type: string, is_required?: bool, options?: array<int, string>}> $fields
     */
    public function createEntity(int $workspaceId, string $name, string $slug, ?string $description, array $fields): int
    {
        $data = Validator::make(
            ['name' => $name, 'slug' => $slug, 'description' => $description],
            ['name' => 'required|string|max:120', 'slug' => 'required|string|max:120', 'description' => 'nullable|string']
        )->validate();

        if ($fields === []) {
            throw new ValidationException(['fields' => ['At least one field must be defined for an entity.']]);
        }

        return \App\Core\Database::transaction(function (PDO $pdo) use ($workspaceId, $data, $fields) {
            $now = date('c');
            $stmt = $pdo->prepare(
                'INSERT INTO entities (workspace_id, name, slug, description, created_at, updated_at) VALUES (:w, :n, :s, :d, :c, :u)'
            );
            $stmt->execute([
                'w' => $workspaceId,
                'n' => $data['name'],
                's' => $data['slug'],
                'd' => $data['description'],
                'c' => $now,
                'u' => $now,
            ]);
            $entityId = (int) $pdo->lastInsertId();

            foreach ($fields as $position => $field) {
                $this->addFieldInternal($pdo, $entityId, $field, $position);
            }

            Logger::info('Entity created', ['entity_id' => $entityId, 'slug' => $data['slug'], 'fields' => count($fields)]);

            return $entityId;
        });
    }

    /**
     * @param array{key: string, label: string, type: string, is_required?: bool, options?: array<int, string>} $field
     */
    public function addField(int $entityId, array $field): int
    {
        $position = (int) ($this->pdo->query('SELECT COUNT(*) FROM entity_fields WHERE entity_id = ' . $entityId)->fetchColumn());

        return $this->addFieldInternal($this->pdo, $entityId, $field, $position);
    }

    private function addFieldInternal(PDO $pdo, int $entityId, array $field, int $position): int
    {
        $validated = Validator::make(
            $field,
            [
                'key' => 'required|string|max:60',
                'label' => 'required|string|max:120',
                'type' => 'required|string',
                'is_required' => 'nullable|boolean',
            ]
        )->validate();

        if (! in_array($field['type'], self::VALID_FIELD_TYPES, true)) {
            throw new ValidationException(['type' => ['Unsupported field type: ' . $field['type']]]);
        }

        $stmt = $pdo->prepare(
            'INSERT INTO entity_fields (entity_id, key, label, type, is_required, validation_rules, options, position, created_at, updated_at)
             VALUES (:e, :k, :l, :t, :r, :v, :o, :p, :c, :u)'
        );
        $now = date('c');
        $stmt->execute([
            'e' => $entityId,
            'k' => $validated['key'],
            'l' => $validated['label'],
            't' => $validated['type'],
            'r' => ! empty($field['is_required']) ? 1 : 0,
            'v' => isset($field['validation_rules']) ? json_encode($field['validation_rules']) : null,
            'o' => isset($field['options']) ? json_encode($field['options']) : null,
            'p' => $position,
            'c' => $now,
            'u' => $now,
        ]);

        return (int) $pdo->lastInsertId();
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function fieldsFor(int $entityId): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM entity_fields WHERE entity_id = :e ORDER BY position ASC');
        $stmt->execute(['e' => $entityId]);

        return $stmt->fetchAll();
    }

    public function findBySlug(int $workspaceId, string $slug): array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM entities WHERE workspace_id = :w AND slug = :s');
        $stmt->execute(['w' => $workspaceId, 's' => $slug]);
        $row = $stmt->fetch();

        if ($row === false) {
            throw new RuntimeException("Entity '{$slug}' not found in workspace {$workspaceId}");
        }

        return $row;
    }
}
