<?php

declare(strict_types=1);

namespace App\Modules\EntityBuilder\Services;

use App\Modules\EntityBuilder\Models\User;
use PDO;

final class UserRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    public function create(int $workspaceId, int $roleId, string $name, string $email, string $password): User
    {
        $now = date('c');
        $stmt = $this->pdo->prepare(
            'INSERT INTO users (workspace_id, role_id, name, email, password_hash, created_at, updated_at) VALUES (:w, :r, :n, :e, :p, :c, :u)'
        );
        $stmt->execute([
            'w' => $workspaceId,
            'r' => $roleId,
            'n' => $name,
            'e' => $email,
            'p' => password_hash($password, PASSWORD_BCRYPT),
            'c' => $now,
            'u' => $now,
        ]);

        return $this->find((int) $this->pdo->lastInsertId());
    }

    public function find(int $id): User
    {
        $stmt = $this->pdo->prepare(
            'SELECT users.*, roles.name AS role_name, roles.level AS role_level
             FROM users JOIN roles ON roles.id = users.role_id
             WHERE users.id = :id'
        );
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();

        if ($row === false) {
            throw new \RuntimeException("User {$id} not found");
        }

        return User::fromRow($row);
    }
}
