<?php

declare(strict_types=1);

namespace App\Modules\EntityBuilder\Services;

use App\Core\Logger;
use PDO;

/**
 * Idempotent role provisioning shared by every module/case seeder (Banquet,
 * Certification, ...): roles are global-by-name (not per-workspace), so
 * "ensure director/manager exist" must not create duplicates when several
 * modules are installed one after another.
 */
final class RoleService
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    /**
     * @param array<string, int> $roles role name => level
     * @return array<string, int> role name => id
     */
    public function ensureRoles(array $roles): array
    {
        $result = [];
        $now = date('c');

        foreach ($roles as $name => $level) {
            $existing = $this->pdo->prepare('SELECT id FROM roles WHERE name = :n');
            $existing->execute(['n' => $name]);
            $id = $existing->fetchColumn();

            if ($id === false) {
                $stmt = $this->pdo->prepare('INSERT INTO roles (name, level, created_at) VALUES (:n, :l, :c)');
                $stmt->execute(['n' => $name, 'l' => $level, 'c' => $now]);
                $id = $this->pdo->lastInsertId();
                Logger::info('Role created', ['name' => $name, 'level' => $level]);
            }

            $result[$name] = (int) $id;
        }

        return $result;
    }
}
