# Revolit — Архитектура (MVP, итерация 1)

## 0. Известное ограничение окружения (важно)

Задача требовала Laravel через `composer create-project laravel/laravel`. В этом
исполнительном окружении исходящий HTTPS к `repo.packagist.org` и
`getcomposer.org` заблокирован политикой egress-прокси (403 на CONNECT),
поэтому ни `laravel/laravel`, ни `illuminate/*`, ни `barryvdh/laravel-dompdf`,
ни `pestphp/pest` установить невозможно — сеть недоступна, это не выбор
исполнителя. Композер сам по себе установлен и рабочий (проверено:
`composer install` с пустым `require` проходит офлайн).

Решение: собран минимальный самостоятельный PHP 8.4 skeleton, архитектурно
повторяющий структуру Laravel (модульные Service/Repository классы,
FormRequest-подобный `Validator`, Policy-класс, PSR-4 автозагрузка через
`composer.json` + `vendor/autoload.php`, файловый роутер вместо `routes/api.php`
+ `Route::`, `Migrator` вместо `php artisan migrate`, консоль `bin/console.php`
вместо `artisan`). Как только сетевой доступ к Packagist появится, все классы
из `app/Core/*` заменяются на нативные Laravel-компоненты (Eloquent, Gate,
FormRequest, `illuminate/database` миграции) практически без изменения
публичного API сервисов — они уже спроектированы как автономные PHP-классы,
не завязанные на глобальный фреймворк.

Тесты выполняются собственным раннером `tests/run.php` (по той же причине
недоступности PHPUnit/Pest через Composer), но по семантике идентичны
`php artisan test`: обнаружение `*Test.php`, `setUp()`, методы `testX`,
in-memory SQLite, пул assert-хелперов. Итог прогона — см. раздел 8.

## 1. Стек

- PHP 8.4 (строгая типизация `declare(strict_types=1)` везде).
- PDO + SQLite (для тестов — `sqlite::memory:`; для разработки —
  `storage/database.sqlite`; DSN конфигурируется через `REVOLIT_DB_DSN`,
  совместим с MySQL/PostgreSQL без изменения кода модулей, т.к. весь SQL
  написан в стандартном диалекте без специфичных для SQLite функций, кроме
  `AUTOINCREMENT`, который трансформируется при миграции на другую БД).
- Собственный тонкий "фреймворк-заменитель" в `app/Core` (Router, Database,
  Validator, Logger, Migrator, ValidationException, Application-контейнер).
- Фронтенд MVP: JSON REST API + простое HTML-представление календаря
  банкетов (Blade недоступен офлайн — используется чистый PHP-шаблон,
  логика и данные полностью реальны, см. `BanquetProcessService::calendar`).
  Полноценный drag&drop конструктор блоков — вне рамок этой итерации
  (зафиксировано как "не реализовано" в отчёте).

## 2. Схема БД

### 2.1 Динамические сущности: JSON-колонка + EAV-проекция (гибрид)

Рассмотрены два варианта:

1. **Чистый EAV** (`entity_record_values` как единственный источник
   истины): гибкая индексация по полю, но чтение одной записи требует JOIN
   по N полям и медленную пересборку объекта в коде.
2. **Чистый JSON** (`entity_records.data`): O(1) чтение/запись всей записи,
   просто для API, но поиск/фильтрация по конкретному полю требует полного
   сканирования JSON во всех СУБД, где нет generated columns.

**Выбор: гибрид.** `entity_records.data` — источник истины для отображения и
CRUD (быстро, просто, естественно ложится на REST JSON). Параллельно при
каждой записи те же значения зеркалируются построчно в
`entity_record_values(entity_record_id, entity_field_id, value)` с индексом
`(entity_field_id, value)` — это даёт дешёвые выборки вида "банкеты на дату X"
(см. `BanquetProcessService::findLastYearBanquets`) без сканирования JSON.
Компромисс — двойная запись при каждом изменении; в этом объёме (десятки
полей на запись) это дешевле, чем поддерживать generated/virtual columns на
разных СУБД или JSON-индексы, которых нет в SQLite.

### 2.2 Таблицы

- `workspaces(id, name, slug, timestamps)` — арендатор/организация.
- `roles(id, name, level, created_at)` — `level` определяет иерархию доступа
  (`director=100`, `manager=50`, ...), используется в Policy.
- `users(id, workspace_id, role_id, name, email, password_hash, timestamps)`.
- `entities(id, workspace_id, name, slug, description, timestamps)` — тип
  сущности ("Банкет", "Клиент"), уникален `(workspace_id, slug)`.
- `entity_fields(id, entity_id, key, label, type, is_required,
  validation_rules JSON, options JSON, position, timestamps)` — метаданные
  поля; `type ∈ {string, text, integer, decimal, boolean, date, select,
  relation}`; `validation_rules` — доп. правила в формате `Validator`
  (например `["email"]`, `["max:10"]`).
- `entity_records(id, entity_id, workspace_id, owner_id, is_owner_only,
  data JSON, timestamps)` — запись; `is_owner_only=1` скрывает запись от всех,
  кроме владельца и ролей с `level >= 100` (директор).
- `entity_record_values(id, entity_record_id, entity_field_id, value,
  timestamps)` — EAV-проекция, см. 2.1.
- `agents(id, workspace_id, name, skills JSON, is_active, timestamps)` —
  сущность "ИИ-агент/исполнитель" (skills = список компетенций).
- `workflows(id, workspace_id, entity_id, name, trigger_event,
  graph JSON, is_active, timestamps)` — `graph = {nodes:[...], edges:[...]}`.
- `workflow_runs(id, workflow_id, entity_record_id, status, log JSON,
  timestamps)` — журнал выполнения (аудит).
- `migrations(id, migration, applied_at)` — служебная таблица `Migrator`.

Банкетные сущности (Банкет/Зал/Меню-позиция/Клиент) НЕ являются отдельными
таблицами — они целиком описаны через `entities`/`entity_fields` сидером
`App\Modules\Banquet\Seeders\BanquetSeeder`, что подтверждает переиспользуемость
ядра для любых будущих отраслевых кейсов.

## 3. REST API

Все ответы — JSON. Ошибки валидации → HTTP 422
`{ "error": "validation_failed", "errors": { "field": ["message"] } }`.
Аутентификация в MVP упрощена до заголовка `X-User-Id` (реальная выдача
JWT/сессий — следующая итерация).

| Метод | Путь | Тело запроса | Ответ | Описание |
|---|---|---|---|---|
| POST | `/api/entities` | `{workspace_id:int, name:string, slug:string, description?:string, fields:[{key,label,type,is_required?,options?,validation_rules?}]}` | `{id:int}` | Создать тип сущности с полями |
| GET | `/api/entities/{id}/fields` | — | `{fields:[...]}` | Метаданные полей сущности |
| POST | `/api/entities/{id}/records` | `{data:{...}, is_owner_only?:bool}` (+ header `X-User-Id`) | `{id:int}` | Создать запись; валидация по метаданным полей |
| GET | `/api/entities/{id}/records` | — (+ `X-User-Id`) | `{records:[...]}` | Список записей, видимых пользователю (owner-only фильтрация) |
| PUT | `/api/records/{id}` | `{data:{...}}` (+ `X-User-Id`) | `{status:"updated"}` | Частичное обновление записи |
| POST | `/api/workflows` | `{workspace_id, entity_id?, name, trigger_event, graph:{nodes,edges}}` | `{id:int}` | Создать процесс |
| POST | `/api/workflows/{id}/run` | `{event:string, entity_record_id:int}` | `{status, run_id, steps:[...]}` | Выполнить процесс для события |
| POST | `/api/banquet/seed` | — | `{workspace_id, roles, entities, workflow_id}` | Засеять пилотный кейс "Банкетный ресторан" |
| GET | `/api/banquet/{workspace_id}/{banquet_entity_id}/calendar` | — | `{calendar:{date:[...]}}` | Список банкетов по датам |

## 4. Структура модулей

```
app/Core/                 — инфраструктура (Database, Router, Validator, Migrator, Logger, Application-контейнер)
app/Modules/EntityBuilder — конструктор сущностей: Entity/Field/Record сервисы, Policy, User/Role
app/Modules/WorkflowEngine— граф процессов, исполнитель шагов, контракт AgentExecutorInterface + Human/AiAgent реализации
app/Modules/AiAgents      — (зарезервировано под будущую модель Agent CRUD + capability matching; в этой итерации Agent описан только миграцией `agents` и используется как метаданные, реального планировщика назначений на агентов нет — см. п.6)
app/Modules/Banquet       — прикладной кейс №1 поверх ядра (манифест модуля, PdfGenerator, BanquetProcessService)
app/Modules/Certification — прикладной кейс №2 поверх ядра (манифест модуля, CertificationProcessService)
app/Modules/Marketplace   — реестр и установщик модулей (ModuleRegistryService, ModuleInstallerService), см. раздел 9
database/migrations       — версионированные SQL-миграции (запускаются Migrator)
routes/api.php            — REST-контракт из раздела 3
tests/Cases               — тесты (Entity Builder, Workflow Engine, Relations, Marketplace, Banquet case, Certification case)
```

Модули не имеют циклических зависимостей: `WorkflowEngine` зависит от
`EntityBuilder` только через прямые PDO-запросы к `entity_records`/
`entity_record_relations` (не через приватные внутренности
`EntityRecordService`), `Banquet`/`Certification` зависят от `EntityBuilder`
и `WorkflowEngine` через их публичные сервисы, а `Marketplace` зависит от
`EntityBuilder`/`WorkflowEngine` тем же образом и ничего не знает о
конкретных отраслевых модулях — `Banquet`/`Certification` лишь предоставляют
манифесты, которые `Marketplace` устанавливает (см. раздел 9).

## 5. RBAC / видимость записей

`EntityRecordPolicy::view(User, record)`:
- если `is_owner_only = 0` — видно всем пользователям workspace;
- если `is_owner_only = 1` — видно владельцу (`owner_id`) и пользователям с
  `role.level >= 100` ("руководитель"/director); менеджерам (`level = 50`) —
  нет, если они не владельцы.

Роли/уровни задаются в БД (`roles.level`), а не хардкодятся в коде — новые
роли и промежуточные уровни доступа добавляются без изменения Policy.

## 6. Workflow Engine

`workflows.graph = { "nodes": [...], "edges": [...] }`.

Типы узлов:
- `trigger` — `{id, type:"trigger", event:"record.created"}` — определяет,
  какое событие запускает граф;
- `condition` — `{id, type:"condition", field, operator, value}`,
  `operator ∈ {equals, not_equals, greater_than, less_than}`; ветвление по
  `edges[].branch ∈ {"true","false"}`;
- `action` — `{id, type:"action", action:"set_field"|"assign", ...}`.
  `set_field` реально пишет в `entity_records.data` через тот же PDO,
  `assign` делегирует `AgentExecutorInterface`.

### AiAgentExecutor — осознанная граница модуля

`AgentExecutorInterface` реализован двумя классами:
- `HumanExecutor` (по умолчанию) — рабочая бизнес-логика: находит
  назначаемого пользователя (явный `user_id` в шаге либо владелец записи) и
  реально сохраняет `assigned_user_id` в `entity_records.data`. Покрыт
  тестами.
- `AiAgentExecutor` — **не заглушка бизнес-логики**, а явно
  задокументированная граница модуля: интеграция с реальной LLM не входит в
  эту итерацию по требованиям задачи. Любой вызов логируется
  (`Logger::warning`) и бросает `NotImplementedException` с понятным
  сообщением, вместо того чтобы молча возвращать фиктивный результат. Тест
  `testAiAgentExecutorThrowsNotImplementedAndIsLogged` подтверждает, что
  `WorkflowRunner` корректно фиксирует такой шаг как `failed` в
  `workflow_runs`, а не проглатывает ошибку.

## 7. Пилотный кейс "Банкетный ресторан"

Полностью конфигурационный (сидер `BanquetSeeder`), сущности: Клиент, Зал,
Меню-позиция, Банкет (все поля — через `entity_fields`, ядро банкетных таблиц
не знает). Процесс (`BanquetProcessService`):

1. `createBanquetWithMenu` — создаёт запись банкета (`status=draft`),
   прикрепляет позиции меню, переводит `status=menu_ready`.
2. `generateClientPdf` — рендерит реальный PDF (валидный PDF 1.4 — объекты,
   xref, trailer собираются вручную, т.к. `barryvdh/laravel-dompdf`
   недоступен офлайн; проверяется в тестах по сигнатуре `%PDF-1.4` и
   `%%EOF`, а не по факту существования файла).
3. `runApprovalWorkflow` — прогоняет граф `тригер → condition(status==
   menu_ready) → set_field(status=pending_approval) → assign(human)`.
4. `findLastYearBanquets` — реальный SQL-запрос по `entity_record_values`
   на дату `date - 1 year ± N дней` (напоминание о прошлогодних банкетах).
5. `calendar` — группировка банкетов по датам для простого списка/календаря
   (HTML-обёртка не реализована в этой итерации, отдаётся JSON — см. отчёт).

## 8. Связи между записями (Entity Record Relations)

Итерация 2 добавила настоящую поддержку связей между записями разных типов
сущностей (не денормализованное дублирование данных, а отдельная таблица):

- `entity_record_relations(id, from_record_id, to_record_id, relation_type,
  created_at)` — типизированная связь между двумя `entity_records`,
  индексирована в обе стороны (`(from_record_id, relation_type)` и
  `(to_record_id, relation_type)`).
- `App\Modules\EntityBuilder\Services\EntityRecordRelationService` —
  `relate()` (с проверкой, что обе записи существуют), `relatedTo()` /
  `relatedFrom()` (с опциональным фильтром по типу), `unrelate()`.
- Используется кейсом "Центр сертификации" для связи "Счёт → Документ"
  (`invoice_for_document`) и Workflow Engine — для связи "Документ →
  Напоминание" (`reminder_for_document`), создаваемой автоматически.

## 9. Маркетплейс модулей

Модуль — это **манифест** (PHP-массив/JSON), декларативно описывающий, какие
типы сущностей и какие шаблоны процессов он привносит, и что для него нужно
из ролей. "Установка" модуля в workspace — это не мок и не копирование
файлов, а реальный вызов существующих `EntityService::createEntity()` и
`WorkflowService::create()` для каждого элемента манифеста — то есть ровно
то же самое, что сделал бы разработчик вручную.

### 9.1 Схема

- `marketplace_modules(id, slug UNIQUE, name, version, author, description,
  status ∈ {draft, published}, manifest JSON, timestamps)` — реестр модулей,
  один модуль — одна строка независимо от количества workspace, куда он
  установлен.
- `module_installations(id, module_id, workspace_id, status ∈ {active,
  uninstalled}, created_entities JSON, created_workflows JSON,
  created_roles JSON, installed_at, uninstalled_at)` — журнал установок:
  фиксирует **что именно** конкретная установка создала (`slug/название →
  id`), чтобы деинсталляция удаляла ровно эти сущности/процессы и ничего
  лишнего.

### 9.2 Контракт манифеста

```jsonc
{
  "slug": "certification-center", "name": "...", "version": "1.0.0",
  "author": "...", "description": "...", "status": "published",
  "roles": {"director": 100, "manager": 50},
  "entities": [
    {"slug": "document", "name": "Документ", "description": "...",
     "fields": [{"key": "status", "label": "Статус", "type": "select",
                 "is_required": true, "options": ["active", "expired", "revoked"]}, ...]}
  ],
  "workflows": [
    {"name": "...", "entity_slug": "document", "trigger_event": "document.expiring_soon",
     "graph": {"nodes": [...], "edges": [...]}}
  ]
}
```

Так как манифест не может заранее знать реальные id сущностей, которые
получатся в конкретном workspace, узлы графа процесса могут ссылаться на
сущность другого модуля/того же манифеста по слагу через
`target_entity_slug` — `ModuleInstallerService` разрешает эту ссылку в
настоящий `target_entity_id` непосредственно перед сохранением workflow
(см. `resolveGraphEntitySlugs()`), после чего в БД хранится обычный граф с
конкретными id, как если бы его собрали вручную.

### 9.3 Сервисы

- `App\Modules\Marketplace\Services\ModuleRegistryService` —
  `register()` (валидирует обязательные поля манифеста, upsert по `slug`,
  выбрасывает `ValidationException` на неполный манифест), `find()`,
  `findBySlug()`, `listPublished()`.
- `App\Modules\Marketplace\Services\ModuleInstallerService` —
  `install(moduleId, workspaceId)`: создаёt роли (идемпотентно, через
  `RoleService::ensureRoles()`), затем реальные сущности+поля
  (`EntityService::createEntity()`), затем реальные workflow
  (`WorkflowService::create()`), затем строку `module_installations` с
  картой созданного. `uninstall(installationId)` — удаляет ровно те
  workflows/entities (что каскадно чистит их поля/записи/значения через
  `ON DELETE CASCADE`) и помечает установку `uninstalled`.

### 9.4 Банкетный ресторан как первый модуль (рефакторинг)

`App\Modules\Banquet\BanquetModuleManifest::manifest()` — тот же набор
сущностей/полей/workflow, что раньше вручную собирал `BanquetSeeder`,
теперь выражен как манифест. `BanquetSeeder::seed()` больше не вызывает
`EntityService`/`WorkflowService` напрямую — он регистрирует манифест через
`ModuleRegistryService` и устанавливает его через `ModuleInstallerService`,
возвращая тот же контракт (`workspace_id`, `roles`, `entities`,
`workflow_id`), поэтому существующий `BanquetCaseTest` не потребовал
изменений — рефакторинг подтверждён тестами, которые ничего не знают о
марткетплейсе.

## 10. Второй прикладной кейс: "Центр сертификации"

Второй модуль маркетплейса (`App\Modules\Certification\CertificationModuleManifest`),
установка через тот же `ModuleInstallerService`. Сущности: `client`
(контрагент), `document` (выданный сертификат/документ), `invoice` (счёт),
`cash_operation` (наличные расчёты по счетам **и** премии менеджерам —
одна сущность, различаемая полем `type`), `reminder` (напоминание,
создаётся только автоматически движком процессов).

`App\Modules\Certification\Services\CertificationProcessService`:

- `createClient()` — переиспользует owner-only механизм Entity Builder:
  руководитель (`role.level >= 100`) может создать приватного клиента,
  которого не видят обычные менеджеры; попытка обычного менеджера создать
  такого клиента отклоняется на уровне сервиса (`RuntimeException`), а
  видимость — на уровне уже существующей `EntityRecordPolicy`, без нового
  кода в ядре.
- `issueDocument()` / `issueInvoice()` — `issueInvoice()` реально связывает
  счёт с документом через `EntityRecordRelationService::relate()`
  (`invoice_for_document`), а не хранит `document_id` внутри JSON счёта.
- `markInvoicePaid()` — доступно только руководителю (проверка
  `roleLevel >= EntityRecordPolicy::DIRECTOR_LEVEL`), обновляет
  `status=paid` и `paid_at` через `EntityRecordService::update()`.
- `documentsByStatusReport()` / `invoiceTotalsReport()` — простые, но
  настоящие отчёты: подсчёт документов по статусам и сумм счетов
  оплачено/не оплачено, посчитанные по реально сохранённым записям (не
  фиктивные цифры).
- `checkExpiringDocuments(workspaceId, asOf, daysAhead)` — находит через
  `entity_record_values` документы со `status=active` и `expiry_date` в
  окне `[asOf, asOf+daysAhead]`, и для каждого, у которого ещё нет
  ожидающего напоминания (`relatedTo($documentId, 'reminder_for_document')`
  без записи со `status=pending`), запускает Workflow Engine
  (`WorkflowRunner::run(..., 'document.expiring_soon', $documentId)`).
  Повторный вызов в тот же день не создаёт дублей — проверено тестом.

### 10.1 Новый тип действия Workflow Engine: `create_record`

Чтобы напоминание создавалось настоящим движком процессов, а не отдельным
хардкодом в сервисе, в `WorkflowRunner` добавлен третий тип `action`,
наравне с `set_field`/`assign`:

- `create_record` — вставляет новую строку `entity_records` в
  `target_entity_id` (в манифесте — `target_entity_slug`, который
  `ModuleInstallerService` резолвит в id при установке), копируя часть
  полей из исходной записи (`copy_fields: {целевойКлюч: исходныйКлюч}`),
  подставляя статические значения (`data`) и, если значение равно
  `"$source_record_id"`, реальный id исходной записи (например,
  `document_id` напоминания = id документа, вызвавшего срабатывание). При
  указанном `link_relation_type` дополнительно создаёт запись в
  `entity_record_relations`. Как и `set_field`, работает через прямой PDO
  (WorkflowEngine по-прежнему не зависит от внутренностей
  `EntityRecordService` — см. раздел 4), это реальная бизнес-логика, а не
  заглушка.

## 11. Тесты

Запуск: `php tests/run.php` (аналог `php artisan test`). На момент сдачи
итерации 2: **19/19 тестов пройдено**:

- Entity Builder (3): создание сущности+полей+записи, отклонение
  невалидных данных, owner-only видимость по ролям.
- Workflow Engine (3): три блока trigger→condition→action, ложная ветка
  условия, явная ошибка `AiAgentExecutor`.
- Кейс банкета (2): полный жизненный цикл с PDF и approval-процессом,
  поиск банкетов "год назад".
- Связи записей — `RelationsTest` (3): связь между записями разных типов
  сущностей и выборка в обе стороны, отказ связать несуществующие записи,
  удаление связи.
- Маркетплейс — `MarketplaceTest` (4): установка модуля из манифеста
  реально создаёт сущности и workflow (проверено через сами
  `EntityService`/прямой SQL, а не через факт вызова), повторная
  регистрация по тому же `slug` обновляет запись, а не дублирует,
  неполный манифест отклоняется `ValidationException`, деинсталляция
  реально удаляет созданные сущности/workflow.
- Кейс "Центр сертификации" — `CertificationCaseTest` (4): создание
  счёта+документа и их связь, owner-only клиент руководителя (менеджеру
  запрещено, менеджер его не видит, руководитель видит), только
  руководитель может пометить счёт оплаченным + отчёты по документам и
  счетам считают правильные суммы, срабатывание напоминания об истечении
  документа (создаёт напоминание, линкует его к документу, не дублирует
  при повторном сканировании, не создаёт напоминание для документа вне
  окна).

## 12. Известные ограничения (для следующей итерации)

- **Drag&drop UI конструктора процессов** не реализован — API и модель
  графа процесса (`workflows.graph`) полностью готовы для такого UI, но
  визуальный редактор — фронтенд-задача вне рамок этой итерации.
- **Реальная LLM-интеграция** (`AiAgentExecutor`) сознательно не
  реализована — граница модуля задокументирована в разделе 6, чтобы не
  писать заглушку под видом бизнес-логики.
- **Кейсы 3 и 4** ("Маркетинговое агентство" и второй центр сертификации с
  мессенджерами) не реализованы в этой итерации — реализован кейс 2
  ("Центр сертификации") как второй прикладной модуль маркетплейса,
  подтверждающий переиспользуемость контракта после Банкетного ресторана.
- Установка модуля (`ModuleInstallerService::install`) не обёрнута в одну
  внешнюю транзакцию: каждый шаг (`createEntity`, `WorkflowService::create`)
  уже атомарен сам по себе, но SQLite-соединение в этом проекте не
  поддерживает вложенные транзакции, поэтому при сбое на середине установки
  часть сущностей может остаться созданной. Для продакшена перед реальным
  Laravel/Eloquent это стоит закрыть через savepoints или flat-транзакцию
  на уровне контроллера.
- Аутентификация по-прежнему упрощена до заголовка `X-User-Id` (см.
  раздел 3) — реальная выдача сессий/JWT осталась следующей итерацией.
