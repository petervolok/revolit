<?php

declare(strict_types=1);

use App\Core\Application;
use App\Core\Router;
use App\Modules\Banquet\BanquetModuleManifest;
use App\Modules\Banquet\Seeders\BanquetSeeder;
use App\Modules\Certification\CertificationModuleManifest;
use App\Modules\Certification\Seeders\CertificationSeeder;

/**
 * REST API surface described in ARCHITECTURE.md. Every handler receives the
 * Application container and the raw JSON request body so it can call real
 * services (no route returns mocked/static data).
 *
 * @param Router $router
 * @param Application $app
 */
return function (Router $router, Application $app): void {
    $input = function (): array {
        $raw = file_get_contents('php://input') ?: '';

        return $raw === '' ? [] : (json_decode($raw, true) ?: []);
    };

    $currentUser = function () use ($app) {
        $userId = (int) ($_SERVER['HTTP_X_USER_ID'] ?? 0);
        if ($userId === 0) {
            throw new RuntimeException('X-User-Id header is required');
        }

        return $app->userRepository()->find($userId);
    };

    // Entities
    $router->post('/api/entities', function () use ($app, $input) {
        $body = $input();
        $id = $app->entityService()->createEntity(
            (int) $body['workspace_id'],
            (string) $body['name'],
            (string) $body['slug'],
            $body['description'] ?? null,
            $body['fields'] ?? []
        );

        return ['id' => $id];
    });

    $router->get('/api/entities/{id}/fields', function (array $params) use ($app) {
        return ['fields' => $app->entityService()->fieldsFor((int) $params['id'])];
    });

    // Records
    $router->post('/api/entities/{id}/records', function (array $params) use ($app, $input, $currentUser) {
        $body = $input();
        $user = $currentUser();
        $recordId = $app->entityRecordService()->create(
            (int) $params['id'],
            $user->workspaceId,
            $user,
            $body['data'] ?? [],
            (bool) ($body['is_owner_only'] ?? false)
        );

        return ['id' => $recordId];
    });

    $router->get('/api/entities/{id}/records', function (array $params) use ($app, $currentUser) {
        $user = $currentUser();

        return ['records' => $app->entityRecordService()->listVisibleFor((int) $params['id'], $user)];
    });

    $router->put('/api/records/{id}', function (array $params) use ($app, $input, $currentUser) {
        $app->entityRecordService()->update((int) $params['id'], $currentUser(), $input()['data'] ?? []);

        return ['status' => 'updated'];
    });

    // Workflows
    $router->post('/api/workflows', function () use ($app, $input) {
        $body = $input();
        $id = $app->workflowService()->create(
            (int) $body['workspace_id'],
            isset($body['entity_id']) ? (int) $body['entity_id'] : null,
            (string) $body['name'],
            (string) $body['trigger_event'],
            $body['graph'] ?? []
        );

        return ['id' => $id];
    });

    $router->post('/api/workflows/{id}/run', function (array $params) use ($app, $input) {
        $body = $input();

        return $app->workflowRunner()->run((int) $params['id'], (string) $body['event'], (int) $body['entity_record_id']);
    });

    // Banquet pilot case
    $router->post('/api/banquet/seed', function () use ($app) {
        return (new BanquetSeeder($app->pdo(), $app->entityService(), $app->workflowService()))->seed();
    });

    $router->get('/api/banquet/{workspace_id}/{banquet_entity_id}/calendar', function (array $params) use ($app) {
        $process = $app->banquetProcess((int) $params['banquet_entity_id'], 0, 0);

        return ['calendar' => $process->calendar((int) $params['workspace_id'])];
    });

    // Certification pilot case (second marketplace module)
    $router->post('/api/certification/seed', function () use ($app) {
        return (new CertificationSeeder($app->pdo(), $app->entityService(), $app->workflowService()))->seed();
    });

    // Marketplace
    $router->get('/api/marketplace/modules', function () use ($app) {
        return ['modules' => $app->moduleRegistryService()->listPublished()];
    });

    $router->post('/api/marketplace/modules', function () use ($app, $input) {
        $body = $input();
        $manifest = $body['manifest'] ?? [];
        if ($manifest === [] && isset($body['slug'])) {
            // Allow submitting the manifest fields flat at the top level too.
            $manifest = $body;
        }

        return ['id' => $app->moduleRegistryService()->register($manifest)];
    });

    $router->post('/api/marketplace/modules/{id}/install', function (array $params) use ($app, $input) {
        $body = $input();

        return $app->moduleInstallerService()->install((int) $params['id'], (int) $body['workspace_id']);
    });

    $router->post('/api/marketplace/installations/{id}/uninstall', function (array $params) use ($app) {
        $app->moduleInstallerService()->uninstall((int) $params['id']);

        return ['status' => 'uninstalled'];
    });

    $router->post('/api/marketplace/register-builtin-modules', function () use ($app) {
        return [
            'banquet_module_id' => $app->moduleRegistryService()->register(BanquetModuleManifest::manifest()),
            'certification_module_id' => $app->moduleRegistryService()->register(CertificationModuleManifest::manifest()),
        ];
    });

    // Relations
    $router->post('/api/records/{id}/relations', function (array $params) use ($app, $input) {
        $body = $input();
        $relationId = $app->relationService()->relate((int) $params['id'], (int) $body['to_record_id'], (string) $body['relation_type']);

        return ['id' => $relationId];
    });

    $router->get('/api/records/{id}/relations', function (array $params) use ($app) {
        return [
            'related_to' => $app->relationService()->relatedTo((int) $params['id']),
            'related_from' => $app->relationService()->relatedFrom((int) $params['id']),
        ];
    });
};
