<?php

declare(strict_types=1);

namespace Tests\Cases;

use App\Modules\Certification\Seeders\CertificationSeeder;
use DateTimeImmutable;
use RuntimeException;
use Tests\Assert;
use Tests\TestCase;

final class CertificationCaseTest extends TestCase
{
    private function seedCase(): array
    {
        return (new CertificationSeeder($this->app->pdo(), $this->app->entityService(), $this->app->workflowService()))->seed();
    }

    private function process(array $seed)
    {
        return $this->app->certificationProcess(
            $seed['entities']['client'],
            $seed['entities']['document'],
            $seed['entities']['invoice'],
            $seed['entities']['cash_operation'],
            $seed['entities']['reminder'],
            $seed['workflow_id'],
        );
    }

    public function testCreatesInvoiceAndDocumentAndLinksThemViaRelation(): void
    {
        $seed = $this->seedCase();
        $userRepo = $this->app->userRepository();
        $manager = $userRepo->create($seed['workspace_id'], $seed['roles']['manager'], 'Manager', 'm' . bin2hex(random_bytes(4)) . '@example.com', 'secret');

        $process = $this->process($seed);

        $clientId = $process->createClient($seed['workspace_id'], $manager, [
            'name' => 'ООО Ромашка', 'phone' => '+79990000000',
        ]);

        $documentId = $process->issueDocument($seed['workspace_id'], $manager, [
            'number' => 'CERT-001',
            'client_id' => $clientId,
            'title' => 'Сертификат соответствия',
            'issued_date' => '2026-08-01',
            'expiry_date' => '2027-08-01',
        ]);

        $invoiceId = $process->issueInvoice($seed['workspace_id'], $manager, [
            'number' => 'INV-001',
            'client_id' => $clientId,
            'amount' => 15000,
            'payment_type' => 'bank',
        ], $documentId);

        $related = $this->app->relationService()->relatedTo($invoiceId, 'invoice_for_document');
        Assert::count(1, $related);
        Assert::same($documentId, (int) $related[0]['id']);

        $invoice = $this->app->entityRecordService()->find($invoiceId);
        $invoiceData = json_decode((string) $invoice['data'], true);
        Assert::same('unpaid', $invoiceData['status']);
    }

    public function testOnlyDirectorCanCreateOwnerOnlyClientAndOthersCannotSeeIt(): void
    {
        $seed = $this->seedCase();
        $userRepo = $this->app->userRepository();
        $manager = $userRepo->create($seed['workspace_id'], $seed['roles']['manager'], 'Manager', 'm1' . bin2hex(random_bytes(4)) . '@example.com', 'secret');
        $director = $userRepo->create($seed['workspace_id'], $seed['roles']['director'], 'Director', 'd1' . bin2hex(random_bytes(4)) . '@example.com', 'secret');

        $process = $this->process($seed);

        Assert::throws(RuntimeException::class, function () use ($process, $seed, $manager) {
            $process->createClient($seed['workspace_id'], $manager, ['name' => 'Секретный клиент', 'phone' => '+7111'], true);
        }, 'A regular manager must not be able to create an owner-only client');

        $privateClientId = $process->createClient($seed['workspace_id'], $director, [
            'name' => 'VIP клиент директора', 'phone' => '+7222',
        ], true);

        $records = $this->app->entityRecordService();
        $visibleToManager = $records->listVisibleFor($seed['entities']['client'], $manager);
        $visibleToDirector = $records->listVisibleFor($seed['entities']['client'], $director);

        foreach ($visibleToManager as $record) {
            Assert::true($record['id'] != $privateClientId, 'Manager must not see the director-only client');
        }

        $foundForDirector = array_filter($visibleToDirector, fn (array $r) => (int) $r['id'] === $privateClientId);
        Assert::count(1, $foundForDirector, 'Director must see their own private client');
    }

    public function testOnlyDirectorCanMarkInvoicePaidAndReportsAggregateCorrectly(): void
    {
        $seed = $this->seedCase();
        $userRepo = $this->app->userRepository();
        $manager = $userRepo->create($seed['workspace_id'], $seed['roles']['manager'], 'Manager', 'm2' . bin2hex(random_bytes(4)) . '@example.com', 'secret');
        $director = $userRepo->create($seed['workspace_id'], $seed['roles']['director'], 'Director', 'd2' . bin2hex(random_bytes(4)) . '@example.com', 'secret');

        $process = $this->process($seed);
        $clientId = $process->createClient($seed['workspace_id'], $manager, ['name' => 'Клиент', 'phone' => '+700']);

        $doc1 = $process->issueDocument($seed['workspace_id'], $manager, [
            'number' => 'CERT-010', 'client_id' => $clientId, 'title' => 'Документ 1', 'issued_date' => '2026-01-01', 'expiry_date' => '2027-01-01',
        ]);
        $doc2 = $process->issueDocument($seed['workspace_id'], $manager, [
            'number' => 'CERT-011', 'client_id' => $clientId, 'title' => 'Документ 2', 'issued_date' => '2026-01-01', 'expiry_date' => '2027-01-01', 'status' => 'revoked',
        ]);

        $invoice1 = $process->issueInvoice($seed['workspace_id'], $manager, ['number' => 'INV-010', 'client_id' => $clientId, 'amount' => 1000, 'payment_type' => 'cash'], $doc1);
        $invoice2 = $process->issueInvoice($seed['workspace_id'], $manager, ['number' => 'INV-011', 'client_id' => $clientId, 'amount' => 2500, 'payment_type' => 'bank'], $doc2);

        Assert::throws(RuntimeException::class, function () use ($process, $manager, $invoice1) {
            $process->markInvoicePaid($manager, $invoice1);
        }, 'A manager must not be able to mark an invoice as paid');

        $process->markInvoicePaid($director, $invoice1);

        $invoiceReport = $process->invoiceTotalsReport($seed['workspace_id']);
        Assert::same(1000.0, $invoiceReport['paid_amount']);
        Assert::same(1, $invoiceReport['paid_count']);
        Assert::same(2500.0, $invoiceReport['unpaid_amount']);
        Assert::same(1, $invoiceReport['unpaid_count']);

        $documentReport = $process->documentsByStatusReport($seed['workspace_id']);
        Assert::same(1, $documentReport['active']);
        Assert::same(1, $documentReport['revoked']);

        // Cash settlement + manager bonus records are plain entity records
        // on the cash_operation entity, real data (no mocked totals).
        $records = $this->app->entityRecordService();
        $records->create($seed['entities']['cash_operation'], $seed['workspace_id'], $manager, [
            'type' => 'cash_receipt', 'invoice_id' => $invoice1, 'manager_user_id' => $manager->id, 'amount' => 1000, 'operation_date' => '2026-09-04',
        ]);
        $bonusId = $records->create($seed['entities']['cash_operation'], $seed['workspace_id'], $manager, [
            'type' => 'manager_bonus', 'manager_user_id' => $manager->id, 'amount' => 100, 'operation_date' => '2026-09-04',
        ]);
        Assert::true($bonusId > 0);
    }

    public function testExpiryReminderWorkflowCreatesLinkedReminderRecordAndAvoidsDuplicates(): void
    {
        $seed = $this->seedCase();
        $userRepo = $this->app->userRepository();
        $manager = $userRepo->create($seed['workspace_id'], $seed['roles']['manager'], 'Manager', 'm3' . bin2hex(random_bytes(4)) . '@example.com', 'secret');

        $process = $this->process($seed);
        $clientId = $process->createClient($seed['workspace_id'], $manager, ['name' => 'Клиент истечения', 'phone' => '+733']);

        $expiringDoc = $process->issueDocument($seed['workspace_id'], $manager, [
            'number' => 'CERT-100', 'client_id' => $clientId, 'title' => 'Скоро истекает', 'issued_date' => '2025-01-01', 'expiry_date' => '2026-09-15',
        ]);
        $farDoc = $process->issueDocument($seed['workspace_id'], $manager, [
            'number' => 'CERT-101', 'client_id' => $clientId, 'title' => 'Далеко от истечения', 'issued_date' => '2025-01-01', 'expiry_date' => '2027-01-01',
        ]);

        $asOf = new DateTimeImmutable('2026-09-04');
        $created = $process->checkExpiringDocuments($seed['workspace_id'], $asOf, 30);

        Assert::count(1, $created, 'Only the document expiring within the 30-day window should trigger a reminder');

        $reminder = $this->app->entityRecordService()->find($created[0]);
        $reminderData = json_decode((string) $reminder['data'], true);
        Assert::same($expiringDoc, $reminderData['document_id']);
        Assert::same($clientId, $reminderData['client_id']);
        Assert::same('CERT-100', $reminderData['document_number']);
        Assert::same('pending', $reminderData['status']);

        $related = $this->app->relationService()->relatedTo($expiringDoc, 'reminder_for_document');
        Assert::count(1, $related);

        // Running the scan again the same day must not create a second reminder.
        $createdAgain = $process->checkExpiringDocuments($seed['workspace_id'], $asOf, 30);
        Assert::count(0, $createdAgain, 'A pending reminder must not be duplicated on a repeat scan');

        // The document far from expiry never gets a reminder.
        $farRelations = $this->app->relationService()->relatedTo($farDoc, 'reminder_for_document');
        Assert::count(0, $farRelations);
    }
}
