<?php

declare(strict_types=1);

namespace Tests\Cases;

use Tests\Assert;
use Tests\TestCase;

final class WorkflowEngineTest extends TestCase
{
    private function seedWorkspaceUserAndEntity(): array
    {
        $pdo = $this->app->pdo();
        $now = date('c');
        $pdo->prepare('INSERT INTO workspaces (name, slug, created_at, updated_at) VALUES (:n,:s,:c,:u)')
            ->execute(['n' => 'WS', 's' => 'ws-' . bin2hex(random_bytes(3)), 'c' => $now, 'u' => $now]);
        $workspaceId = (int) $pdo->lastInsertId();

        $pdo->prepare('INSERT INTO roles (name, level, created_at) VALUES (:n,:l,:c)')
            ->execute(['n' => 'manager-' . bin2hex(random_bytes(2)), 'l' => 50, 'c' => $now]);
        $roleId = (int) $pdo->lastInsertId();
        $user = $this->app->userRepository()->create($workspaceId, $roleId, 'U', 'u' . bin2hex(random_bytes(4)) . '@example.com', 'secret');

        $entityId = $this->app->entityService()->createEntity($workspaceId, 'Задача', 'task', null, [
            ['key' => 'status', 'label' => 'Статус', 'type' => 'select', 'is_required' => true, 'options' => ['new', 'in_progress', 'done']],
        ]);

        return [$workspaceId, $user, $entityId];
    }

    public function testThreeBlockWorkflowSetsFieldAndAssignsHuman(): void
    {
        [$workspaceId, $user, $entityId] = $this->seedWorkspaceUserAndEntity();

        $recordId = $this->app->entityRecordService()->create($entityId, $workspaceId, $user, ['status' => 'new']);

        $workflowId = $this->app->workflowService()->create($workspaceId, $entityId, 'Task auto-progress', 'record.created', [
            'nodes' => [
                ['id' => 'trigger', 'type' => 'trigger', 'event' => 'record.created'],
                ['id' => 'is_new', 'type' => 'condition', 'field' => 'status', 'operator' => 'equals', 'value' => 'new'],
                ['id' => 'set_progress', 'type' => 'action', 'action' => 'set_field', 'field' => 'status', 'value' => 'in_progress'],
                ['id' => 'assign', 'type' => 'action', 'action' => 'assign', 'assignee_type' => 'human', 'user_id' => $user->id],
            ],
            'edges' => [
                ['from' => 'trigger', 'to' => 'is_new'],
                ['from' => 'is_new', 'to' => 'set_progress', 'branch' => 'true'],
                ['from' => 'set_progress', 'to' => 'assign'],
            ],
        ]);

        $result = $this->app->workflowRunner()->run($workflowId, 'record.created', $recordId);

        Assert::same('completed', $result['status']);
        Assert::count(4, $result['steps']);

        $record = $this->app->entityRecordService()->find($recordId);
        $data = json_decode((string) $record['data'], true);

        Assert::same('in_progress', $data['status']);
        Assert::same($user->id, $data['assigned_user_id']);
    }

    public function testConditionFalseBranchSkipsAction(): void
    {
        [$workspaceId, $user, $entityId] = $this->seedWorkspaceUserAndEntity();

        $recordId = $this->app->entityRecordService()->create($entityId, $workspaceId, $user, ['status' => 'done']);

        $workflowId = $this->app->workflowService()->create($workspaceId, $entityId, 'Task auto-progress 2', 'record.created', [
            'nodes' => [
                ['id' => 'trigger', 'type' => 'trigger', 'event' => 'record.created'],
                ['id' => 'is_new', 'type' => 'condition', 'field' => 'status', 'operator' => 'equals', 'value' => 'new'],
                ['id' => 'set_progress', 'type' => 'action', 'action' => 'set_field', 'field' => 'status', 'value' => 'in_progress'],
            ],
            'edges' => [
                ['from' => 'trigger', 'to' => 'is_new'],
                ['from' => 'is_new', 'to' => 'set_progress', 'branch' => 'true'],
            ],
        ]);

        $this->app->workflowRunner()->run($workflowId, 'record.created', $recordId);

        $record = $this->app->entityRecordService()->find($recordId);
        $data = json_decode((string) $record['data'], true);

        Assert::same('done', $data['status'], 'Status should remain unchanged when condition branch is false');
    }

    public function testAiAgentExecutorThrowsNotImplementedAndIsLogged(): void
    {
        [$workspaceId, $user, $entityId] = $this->seedWorkspaceUserAndEntity();
        $recordId = $this->app->entityRecordService()->create($entityId, $workspaceId, $user, ['status' => 'new']);

        $workflowId = $this->app->workflowService()->create($workspaceId, $entityId, 'AI assignment', 'record.created', [
            'nodes' => [
                ['id' => 'trigger', 'type' => 'trigger', 'event' => 'record.created'],
                ['id' => 'assign_ai', 'type' => 'action', 'action' => 'assign', 'assignee_type' => 'ai_agent'],
            ],
            'edges' => [
                ['from' => 'trigger', 'to' => 'assign_ai'],
            ],
        ]);

        $result = $this->app->workflowRunner()->run($workflowId, 'record.created', $recordId);

        Assert::same('failed', $result['status']);
        Assert::contains('AiAgentExecutor', (string) $result['steps'][1]['error']);
    }
}
