<?php

declare(strict_types=1);

namespace Tests\Cases;

use App\Modules\Banquet\Seeders\BanquetSeeder;
use Tests\Assert;
use Tests\TestCase;

final class BanquetCaseTest extends TestCase
{
    public function testFullBanquetLifecycleCreatesPdfAndRunsApproval(): void
    {
        $seed = (new BanquetSeeder($this->app->pdo(), $this->app->entityService(), $this->app->workflowService()))->seed();

        $records = $this->app->entityRecordService();
        $userRepo = $this->app->userRepository();
        $manager = $userRepo->create($seed['workspace_id'], $seed['roles']['manager'], 'Manager', 'm' . bin2hex(random_bytes(4)) . '@example.com', 'secret');

        $clientId = $records->create($seed['entities']['client'], $seed['workspace_id'], $manager, ['name' => 'Ольга', 'phone' => '+79990000000']);
        $hallId = $records->create($seed['entities']['hall'], $seed['workspace_id'], $manager, ['name' => 'Малый зал', 'tables_count' => 10, 'capacity' => 80]);
        $menuId1 = $records->create($seed['entities']['menu_item'], $seed['workspace_id'], $manager, ['name' => 'Салат Оливье', 'price' => 350, 'category' => 'starter']);
        $menuId2 = $records->create($seed['entities']['menu_item'], $seed['workspace_id'], $manager, ['name' => 'Стейк', 'price' => 1200, 'category' => 'main']);

        $process = $this->app->banquetProcess($seed['entities']['banquet'], $seed['entities']['menu_item'], $seed['workflow_id']);

        $banquetId = $process->createBanquetWithMenu($seed['workspace_id'], $manager, [
            'client_id' => $clientId,
            'hall_id' => $hallId,
            'date' => '2026-09-20',
            'guests_count' => 60,
        ], [$menuId1, $menuId2]);

        $record = $records->find($banquetId);
        $data = json_decode((string) $record['data'], true);
        Assert::same('menu_ready', $data['status']);

        $pdfPath = sys_get_temp_dir() . '/banquet_' . $banquetId . '.pdf';
        $process->generateClientPdf($banquetId, $pdfPath);

        Assert::true(file_exists($pdfPath), 'PDF file should be generated');
        $bytes = file_get_contents($pdfPath);
        Assert::true(str_starts_with($bytes, '%PDF-1.4'), 'PDF should start with a valid PDF header');
        Assert::contains('%%EOF', $bytes, 'PDF should be properly terminated');

        $result = $process->runApprovalWorkflow($banquetId);
        Assert::same('completed', $result['status']);

        $afterWorkflow = json_decode((string) $records->find($banquetId)['data'], true);
        Assert::same('pending_approval', $afterWorkflow['status']);
        Assert::same($manager->id, $afterWorkflow['assigned_user_id']);

        unlink($pdfPath);
    }

    public function testLastYearBanquetReminderFindsMatchingDates(): void
    {
        $seed = (new BanquetSeeder($this->app->pdo(), $this->app->entityService(), $this->app->workflowService()))->seed();
        $records = $this->app->entityRecordService();
        $userRepo = $this->app->userRepository();
        $manager = $userRepo->create($seed['workspace_id'], $seed['roles']['manager'], 'Manager', 'm2' . bin2hex(random_bytes(4)) . '@example.com', 'secret');
        $clientId = $records->create($seed['entities']['client'], $seed['workspace_id'], $manager, ['name' => 'Клиент', 'phone' => '+7000']);
        $hallId = $records->create($seed['entities']['hall'], $seed['workspace_id'], $manager, ['name' => 'Зал', 'tables_count' => 5, 'capacity' => 40]);

        $process = $this->app->banquetProcess($seed['entities']['banquet'], $seed['entities']['menu_item'], $seed['workflow_id']);

        // Banquet exactly one year before the target date.
        $process->createBanquetWithMenu($seed['workspace_id'], $manager, [
            'client_id' => $clientId, 'hall_id' => $hallId, 'date' => '2025-09-18', 'guests_count' => 30,
        ], []);

        // Banquet far away in time - must NOT be picked up by the reminder.
        $process->createBanquetWithMenu($seed['workspace_id'], $manager, [
            'client_id' => $clientId, 'hall_id' => $hallId, 'date' => '2024-01-01', 'guests_count' => 10,
        ], []);

        $matches = $process->findLastYearBanquets($seed['workspace_id'], '2026-09-20', windowDays: 3);

        Assert::count(1, $matches, 'Only the banquet from ~1 year before the target date should match');
    }
}
