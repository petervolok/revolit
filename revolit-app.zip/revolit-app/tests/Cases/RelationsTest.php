<?php

declare(strict_types=1);

namespace Tests\Cases;

use Tests\Assert;
use Tests\TestCase;

final class RelationsTest extends TestCase
{
    private function makeWorkspaceAndUser(): array
    {
        $pdo = $this->app->pdo();
        $now = date('c');
        $pdo->prepare('INSERT INTO workspaces (name, slug, created_at, updated_at) VALUES (:n,:s,:c,:u)')
            ->execute(['n' => 'WS', 's' => 'ws-' . bin2hex(random_bytes(3)), 'c' => $now, 'u' => $now]);
        $workspaceId = (int) $pdo->lastInsertId();

        $pdo->prepare('INSERT INTO roles (name, level, created_at) VALUES (:n,:l,:c)')
            ->execute(['n' => 'manager-' . bin2hex(random_bytes(2)), 'l' => 50, 'c' => $now]);
        $roleId = (int) $pdo->lastInsertId();
        $user = $this->app->userRepository()->create($workspaceId, $roleId, 'U', 'u' . bin2hex(random_bytes(4)) . '@example.com', 'secret');

        return [$workspaceId, $user];
    }

    public function testRelatesTwoRecordsOfDifferentEntitiesAndQueriesBothDirections(): void
    {
        [$workspaceId, $user] = $this->makeWorkspaceAndUser();

        $invoiceEntity = $this->app->entityService()->createEntity($workspaceId, 'Счёт', 'invoice', null, [
            ['key' => 'number', 'label' => 'Номер', 'type' => 'string', 'is_required' => true],
        ]);
        $documentEntity = $this->app->entityService()->createEntity($workspaceId, 'Документ', 'document', null, [
            ['key' => 'title', 'label' => 'Название', 'type' => 'string', 'is_required' => true],
        ]);

        $records = $this->app->entityRecordService();
        $invoiceId = $records->create($invoiceEntity, $workspaceId, $user, ['number' => 'INV-1']);
        $documentId = $records->create($documentEntity, $workspaceId, $user, ['title' => 'Сертификат №1']);

        $relations = $this->app->relationService();
        $relationId = $relations->relate($invoiceId, $documentId, 'invoice_for_document');
        Assert::true($relationId > 0);

        $forwardResults = $relations->relatedTo($invoiceId, 'invoice_for_document');
        Assert::count(1, $forwardResults);
        Assert::same($documentId, (int) $forwardResults[0]['id']);

        $backwardResults = $relations->relatedFrom($documentId, 'invoice_for_document');
        Assert::count(1, $backwardResults);
        Assert::same($invoiceId, (int) $backwardResults[0]['id']);

        // A different relation type should not match.
        Assert::count(0, $relations->relatedTo($invoiceId, 'something_else'));
    }

    public function testRelateRejectsNonExistentRecords(): void
    {
        [, $user] = $this->makeWorkspaceAndUser();
        $relations = $this->app->relationService();

        Assert::throws(\RuntimeException::class, function () use ($relations) {
            $relations->relate(999999, 888888, 'whatever');
        });
    }

    public function testUnrelateRemovesTheRelation(): void
    {
        [$workspaceId, $user] = $this->makeWorkspaceAndUser();

        $entityId = $this->app->entityService()->createEntity($workspaceId, 'Заметка', 'note', null, [
            ['key' => 'text', 'label' => 'Текст', 'type' => 'string', 'is_required' => true],
        ]);
        $records = $this->app->entityRecordService();
        $a = $records->create($entityId, $workspaceId, $user, ['text' => 'A']);
        $b = $records->create($entityId, $workspaceId, $user, ['text' => 'B']);

        $relations = $this->app->relationService();
        $relationId = $relations->relate($a, $b, 'linked');
        Assert::count(1, $relations->relatedTo($a, 'linked'));

        $relations->unrelate($relationId);
        Assert::count(0, $relations->relatedTo($a, 'linked'));
    }
}
