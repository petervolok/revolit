<?php

declare(strict_types=1);

namespace Tests\Cases;

use App\Modules\Banquet\BanquetModuleManifest;
use App\Core\ValidationException;
use Tests\Assert;
use Tests\TestCase;

final class MarketplaceTest extends TestCase
{
    private function createWorkspace(): int
    {
        $pdo = $this->app->pdo();
        $now = date('c');
        $pdo->prepare('INSERT INTO workspaces (name, slug, created_at, updated_at) VALUES (:n,:s,:c,:u)')
            ->execute(['n' => 'WS', 's' => 'ws-' . bin2hex(random_bytes(3)), 'c' => $now, 'u' => $now]);

        return (int) $pdo->lastInsertId();
    }

    public function testInstallingModuleFromManifestReallyCreatesEntitiesAndWorkflow(): void
    {
        $registry = $this->app->moduleRegistryService();
        $moduleId = $registry->register(BanquetModuleManifest::manifest());
        Assert::true($moduleId > 0);

        $module = $registry->find($moduleId);
        Assert::same('banquet-restaurant', $module['slug']);
        Assert::same('published', $module['status']);

        $workspaceId = $this->createWorkspace();
        $installation = $this->app->moduleInstallerService()->install($moduleId, $workspaceId);

        Assert::count(4, $installation['entities'], 'Manifest declares 4 entities');
        Assert::true(isset($installation['entities']['banquet']));
        Assert::true(isset($installation['workflows']['Банкет: согласование']));
        Assert::true(isset($installation['roles']['director']));
        Assert::true(isset($installation['roles']['manager']));

        // The installed entity is a real, usable entity type - verified by
        // creating an actual record against it through the normal service.
        $bannquetEntityId = $installation['entities']['banquet'];
        $fields = $this->app->entityService()->fieldsFor($bannquetEntityId);
        Assert::true(count($fields) > 0, 'Installed entity should have real field metadata');

        $workflowStmt = $this->app->pdo()->prepare('SELECT * FROM workflows WHERE id = :id');
        $workflowStmt->execute(['id' => $installation['workflows']['Банкет: согласование']]);
        Assert::true($workflowStmt->fetch() !== false, 'Installed workflow row must exist');
    }

    public function testRegisteringSameSlugTwiceUpdatesInsteadOfDuplicating(): void
    {
        $registry = $this->app->moduleRegistryService();
        $manifest = BanquetModuleManifest::manifest();

        $firstId = $registry->register($manifest);
        $manifest['version'] = '1.0.1';
        $secondId = $registry->register($manifest);

        Assert::same($firstId, $secondId, 'Re-registering the same slug must update, not duplicate');

        $count = (int) $this->app->pdo()->query("SELECT COUNT(*) FROM marketplace_modules WHERE slug = 'banquet-restaurant'")->fetchColumn();
        Assert::same(1, $count);

        $module = $registry->find($firstId);
        Assert::same('1.0.1', $module['version']);
    }

    public function testRegisterRejectsIncompleteManifest(): void
    {
        $registry = $this->app->moduleRegistryService();

        Assert::throws(ValidationException::class, function () use ($registry) {
            $registry->register(['slug' => 'broken-module']);
        });
    }

    public function testUninstallRemovesInstalledEntitiesAndWorkflow(): void
    {
        $registry = $this->app->moduleRegistryService();
        $moduleId = $registry->register(BanquetModuleManifest::manifest());
        $workspaceId = $this->createWorkspace();

        $installation = $this->app->moduleInstallerService()->install($moduleId, $workspaceId);
        $bannquetEntityId = $installation['entities']['banquet'];
        $workflowId = $installation['workflows']['Банкет: согласование'];

        $this->app->moduleInstallerService()->uninstall($installation['installation_id']);

        $stmt = $this->app->pdo()->prepare('SELECT COUNT(*) FROM entities WHERE id = :id');
        $stmt->execute(['id' => $bannquetEntityId]);
        Assert::same(0, (int) $stmt->fetchColumn(), 'Entity created by the module must be removed on uninstall');

        $wfStmt = $this->app->pdo()->prepare('SELECT COUNT(*) FROM workflows WHERE id = :id');
        $wfStmt->execute(['id' => $workflowId]);
        Assert::same(0, (int) $wfStmt->fetchColumn(), 'Workflow created by the module must be removed on uninstall');

        $installStmt = $this->app->pdo()->prepare("SELECT status FROM module_installations WHERE id = :id");
        $installStmt->execute(['id' => $installation['installation_id']]);
        Assert::same('uninstalled', $installStmt->fetchColumn());
    }
}
