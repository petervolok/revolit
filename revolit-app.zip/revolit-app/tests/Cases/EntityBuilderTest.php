<?php

declare(strict_types=1);

namespace Tests\Cases;

use App\Core\ValidationException;
use App\Modules\EntityBuilder\Models\User;
use Tests\Assert;
use Tests\TestCase;

final class EntityBuilderTest extends TestCase
{
    private function makeWorkspaceAndUser(string $role, int $level): array
    {
        $pdo = $this->app->pdo();
        $now = date('c');
        $pdo->prepare('INSERT INTO workspaces (name, slug, created_at, updated_at) VALUES (:n,:s,:c,:u)')
            ->execute(['n' => 'WS', 's' => 'ws-' . bin2hex(random_bytes(3)), 'c' => $now, 'u' => $now]);
        $workspaceId = (int) $pdo->lastInsertId();

        $pdo->prepare('INSERT INTO roles (name, level, created_at) VALUES (:n,:l,:c)')
            ->execute(['n' => $role . '-' . bin2hex(random_bytes(2)), 'l' => $level, 'c' => $now]);
        $roleId = (int) $pdo->lastInsertId();

        $user = $this->app->userRepository()->create($workspaceId, $roleId, 'Test User', 'u' . bin2hex(random_bytes(4)) . '@example.com', 'secret');

        return [$workspaceId, $user];
    }

    public function testCreatesEntityWithFieldsAndRecord(): void
    {
        [$workspaceId, $user] = $this->makeWorkspaceAndUser('manager', 50);

        $entityId = $this->app->entityService()->createEntity($workspaceId, 'Клиент', 'client', 'Клиенты', [
            ['key' => 'name', 'label' => 'Имя', 'type' => 'string', 'is_required' => true],
            ['key' => 'age', 'label' => 'Возраст', 'type' => 'integer', 'is_required' => false],
        ]);

        Assert::true($entityId > 0);

        $recordId = $this->app->entityRecordService()->create($entityId, $workspaceId, $user, [
            'name' => 'Иван Иванов',
            'age' => 34,
        ]);

        $record = $this->app->entityRecordService()->find($recordId);
        $data = json_decode((string) $record['data'], true);

        Assert::same('Иван Иванов', $data['name']);
        Assert::same(34, $data['age']);
    }

    public function testRejectsRecordViolatingFieldValidation(): void
    {
        [$workspaceId, $user] = $this->makeWorkspaceAndUser('manager', 50);

        $entityId = $this->app->entityService()->createEntity($workspaceId, 'Клиент', 'client', null, [
            ['key' => 'name', 'label' => 'Имя', 'type' => 'string', 'is_required' => true],
            ['key' => 'email', 'label' => 'Email', 'type' => 'string', 'is_required' => true, 'validation_rules' => ['email']],
        ]);

        Assert::throws(ValidationException::class, function () use ($entityId, $workspaceId, $user) {
            $this->app->entityRecordService()->create($entityId, $workspaceId, $user, [
                'name' => 'Пётр',
                'email' => 'not-an-email',
            ]);
        });
    }

    public function testOwnerOnlyRecordsAreHiddenFromManagerButVisibleToDirector(): void
    {
        [$workspaceId, $manager] = $this->makeWorkspaceAndUser('manager', 50);
        $pdo = $this->app->pdo();
        $now = date('c');
        $pdo->prepare('INSERT INTO roles (name, level, created_at) VALUES (:n,:l,:c)')
            ->execute(['n' => 'director-' . bin2hex(random_bytes(2)), 'l' => 100, 'c' => $now]);
        $directorRoleId = (int) $pdo->lastInsertId();
        $director = $this->app->userRepository()->create($workspaceId, $directorRoleId, 'Director', 'dir' . bin2hex(random_bytes(4)) . '@example.com', 'secret');

        $entityId = $this->app->entityService()->createEntity($workspaceId, 'Заметка', 'note', null, [
            ['key' => 'text', 'label' => 'Текст', 'type' => 'string', 'is_required' => true],
        ]);

        $records = $this->app->entityRecordService();
        $records->create($entityId, $workspaceId, $manager, ['text' => 'Открытая запись'], isOwnerOnly: false);
        $records->create($entityId, $workspaceId, $director, ['text' => 'Секретная запись директора'], isOwnerOnly: true);

        $visibleToManager = $records->listVisibleFor($entityId, $manager);
        $visibleToDirector = $records->listVisibleFor($entityId, $director);

        Assert::count(1, $visibleToManager, 'Manager should only see the non-owner-only record');
        Assert::count(2, $visibleToDirector, 'Director should see both records');
    }
}
