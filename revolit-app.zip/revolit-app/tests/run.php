<?php

declare(strict_types=1);

/**
 * Minimal test runner substituting PHPUnit/Pest, which could not be
 * installed because this environment has no network access to Packagist
 * (see ARCHITECTURE.md, "Known environment limitation"). Discovers every
 * *Test.php class under tests/Cases, instantiates it, calls setUp() then
 * every public method starting with "test", reporting pass/fail like a
 * standard PHPUnit run.
 */

require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/TestCase.php';
require __DIR__ . '/Assert.php';

$casesDir = __DIR__ . '/Cases';
$files = glob($casesDir . '/*Test.php') ?: [];
sort($files);

$total = 0;
$failed = 0;
$failures = [];

foreach ($files as $file) {
    require_once $file;
    $className = 'Tests\\Cases\\' . basename($file, '.php');

    if (! class_exists($className)) {
        continue;
    }

    $instance = new $className();
    $methods = array_filter(get_class_methods($instance), fn ($m) => str_starts_with($m, 'test'));

    foreach ($methods as $method) {
        $total++;
        $label = $className . '::' . $method;

        try {
            $instance->setUp();
            $instance->$method();
            echo "PASS  {$label}\n";
        } catch (\Throwable $exception) {
            $failed++;
            $failures[] = $label . ' - ' . $exception->getMessage();
            echo "FAIL  {$label} - " . $exception->getMessage() . "\n";
        }
    }
}

echo "\n" . ($total - $failed) . "/{$total} tests passed.\n";

if ($failures !== []) {
    echo "\nFailures:\n";
    foreach ($failures as $failure) {
        echo " - {$failure}\n";
    }
    exit(1);
}

exit(0);
