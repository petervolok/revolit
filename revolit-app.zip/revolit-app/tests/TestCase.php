<?php

declare(strict_types=1);

namespace Tests;

use App\Core\Application;
use App\Core\Database;

/**
 * Base test case. Each test gets a fresh in-memory SQLite database with
 * migrations applied - standard practice for Laravel-style test isolation,
 * substituting the RefreshDatabase trait (unavailable offline).
 */
class TestCase
{
    protected Application $app;

    public function setUp(): void
    {
        Database::reset();
        $this->app = new Application('sqlite::memory:');
        $this->app->migrate();
    }
}
