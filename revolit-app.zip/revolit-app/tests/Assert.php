<?php

declare(strict_types=1);

namespace Tests;

final class AssertionFailedException extends \RuntimeException
{
}

final class Assert
{
    public static function true(bool $condition, string $message = 'Expected true'): void
    {
        if (! $condition) {
            throw new AssertionFailedException($message);
        }
    }

    public static function false(bool $condition, string $message = 'Expected false'): void
    {
        self::true(! $condition, $message);
    }

    public static function same(mixed $expected, mixed $actual, string $message = ''): void
    {
        if ($expected !== $actual) {
            $expectedStr = is_scalar($expected) ? (string) $expected : json_encode($expected);
            $actualStr = is_scalar($actual) ? (string) $actual : json_encode($actual);
            throw new AssertionFailedException($message !== '' ? $message : "Expected [{$expectedStr}], got [{$actualStr}]");
        }
    }

    public static function count(int $expected, array|\Countable $actual, string $message = ''): void
    {
        self::same($expected, count($actual), $message !== '' ? $message : "Expected count {$expected}, got " . count($actual));
    }

    public static function throws(string $exceptionClass, callable $callback, string $message = ''): void
    {
        try {
            $callback();
        } catch (\Throwable $exception) {
            if ($exception instanceof $exceptionClass) {
                return;
            }

            throw new AssertionFailedException(
                $message !== '' ? $message : "Expected {$exceptionClass}, got " . get_class($exception) . ': ' . $exception->getMessage()
            );
        }

        throw new AssertionFailedException($message !== '' ? $message : "Expected {$exceptionClass} to be thrown, none was");
    }

    public static function contains(string $needle, string $haystack, string $message = ''): void
    {
        if (! str_contains($haystack, $needle)) {
            throw new AssertionFailedException($message !== '' ? $message : "Expected to find '{$needle}' in given string");
        }
    }
}
