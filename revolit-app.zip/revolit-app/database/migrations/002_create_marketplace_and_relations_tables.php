<?php

declare(strict_types=1);


return [
    'up' => function (PDO $pdo): void {
        // Relations between entity_records of possibly different entity
        // types (e.g. "invoice" <-> "document"). Generic, typed by
        // relation_type so any future module can define its own semantics
        // without new tables. See App\Modules\EntityBuilder\Services\EntityRecordRelationService.
        $pdo->exec(<<<SQL
            CREATE TABLE entity_record_relations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                from_record_id INTEGER NOT NULL REFERENCES entity_records(id) ON DELETE CASCADE,
                to_record_id INTEGER NOT NULL REFERENCES entity_records(id) ON DELETE CASCADE,
                relation_type TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        SQL);

        $pdo->exec('CREATE INDEX idx_relations_from ON entity_record_relations(from_record_id, relation_type)');
        $pdo->exec('CREATE INDEX idx_relations_to ON entity_record_relations(to_record_id, relation_type)');

        // Marketplace: a module is a versioned, publishable manifest
        // (entity type definitions + workflow templates + required roles).
        // See App\Modules\Marketplace.
        $pdo->exec(<<<SQL
            CREATE TABLE marketplace_modules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                slug TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                version TEXT NOT NULL,
                author TEXT NOT NULL,
                description TEXT,
                status TEXT NOT NULL DEFAULT 'draft',
                manifest TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        SQL);

        // One row per "install into a workspace" operation. Tracks exactly
        // which entities/workflows/roles were created by that install so
        // uninstall() can remove precisely those, and nothing else.
        $pdo->exec(<<<SQL
            CREATE TABLE module_installations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                module_id INTEGER NOT NULL REFERENCES marketplace_modules(id) ON DELETE CASCADE,
                workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
                status TEXT NOT NULL DEFAULT 'active',
                created_entities TEXT NOT NULL DEFAULT '{}',
                created_workflows TEXT NOT NULL DEFAULT '{}',
                created_roles TEXT NOT NULL DEFAULT '{}',
                installed_at TEXT NOT NULL,
                uninstalled_at TEXT
            )
        SQL);
    },
];
