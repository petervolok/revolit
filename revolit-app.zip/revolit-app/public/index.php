<?php

declare(strict_types=1);

require __DIR__ . '/../vendor/autoload.php';

use App\Core\Application;
use App\Core\Router;

$app = new Application();
$router = new Router();

(require __DIR__ . '/../routes/api.php')($router, $app);

$router->dispatch($_SERVER['REQUEST_METHOD'] ?? 'GET', $_SERVER['REQUEST_URI'] ?? '/');
